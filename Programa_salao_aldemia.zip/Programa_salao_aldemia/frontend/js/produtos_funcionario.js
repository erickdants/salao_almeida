const BASE_URL = "http://localhost:3000";


async function carregarProdutos() {
  const tbody = document.querySelector("#tabelaProdutos tbody");
  if (!tbody) return;

  const res = await fetch(`${BASE_URL}/produtos?todos=true`);
  const produtos = await res.json();

  tbody.innerHTML = "";

  produtos.forEach(p => {
    tbody.innerHTML += `
      <tr>
        <td>${p.cod_produto}</td>
        <td>${p.nome_produto}</td>
        <td>${p.descricao ?? ""}</td>
        <td>${p.estoque_produto}</td>
        <td>
          ${p.ativo
            ? `<span class="badge bg-success">Ativo</span>`
            : `<span class="badge bg-secondary">Inativo</span>`}
        </td>
        <td>
          <button class="btn btn-sm btn-primary me-1"
            onclick="editarProduto(${p.cod_produto})">
            Editar
          </button>

          <button class="btn btn-sm btn-secondary me-1"
            onclick="verAgendasProduto(${p.cod_produto}, '${p.nome_produto}')">
            Ver Agendas
          </button>

          ${p.ativo
            ? `<button class="btn btn-sm btn-danger"
                onclick="desativarProduto(${p.cod_produto})">
                Desativar
              </button>`
            : `<button class="btn btn-sm btn-success"
                onclick="reativarProduto(${p.cod_produto})">
                Reativar
              </button>`}
        </td>
      </tr>
    `;
  });
}


function editarProduto(cod) {
  localStorage.setItem("produto_editar", cod);
  window.location.href = "produto_funcionario_editar.html";
}

async function desativarProduto(cod) {
  if (!confirm("Desativar produto?")) return;
  await fetch(`${BASE_URL}/produtos/${cod}`, { method: "DELETE" });
  carregarProdutos();
}

async function reativarProduto(cod) {
  if (!confirm("Reativar produto?")) return;
  await fetch(`${BASE_URL}/produtos/${cod}/reativar`, { method: "PUT" });
  carregarProdutos();
}


async function verAgendasProduto(cod, nome) {
  document.getElementById("tituloAgendas").textContent = `Produto: ${nome}`;
  document.getElementById("panelAgendas").style.display = "block";

  const res = await fetch(`${BASE_URL}/produtos/${cod}/utilizacoes`);
  const dados = await res.json();

  const tbody = document.getElementById("tbodyAgendas");

  tbody.innerHTML = dados.length
    ? dados.map(d => `
        <tr>
          <td>${d.cod_agenda ?? d.cod_agenda_prod ?? d.cod_agendas}</td>
          <td>${d.quant_vendido_produto ?? d.quant_produto ?? d.quantidade ?? 1}</td>
        </tr>
      `).join("")
    : `
      <tr>
        <td colspan="2" class="text-center">
          Nenhuma agenda encontrada
        </td>
      </tr>
    `;
}


function fecharAgendas() {
  document.getElementById("panelAgendas").style.display = "none";
}

document.addEventListener("DOMContentLoaded", carregarProdutos);



const formCadastrar = document.querySelector("#formCadastrarProduto");

if (formCadastrar) {
  formCadastrar.addEventListener("submit", async (e) => {
    e.preventDefault();

    const dados = {
      nome_produto: document.getElementById("nome_produto").value,
      descricao: document.getElementById("descricao").value,
      estoque_produto: document.getElementById("estoque_produto").value
    };

    try {
      await fetch(`${BASE_URL}/produtos`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dados)
      });

      alert("Produto cadastrado com sucesso!");
      window.location.href = "produtos_funcionario.html";
    } catch (err) {
      console.error("Erro cadastrar produto:", err);
      alert("Erro ao cadastrar produto");
    }
  });
}


const formEditar = document.querySelector("#formEditarProduto");

if (formEditar) {
  const cod = localStorage.getItem("produto_editar");

  async function carregarProduto() {
    try {
      const res = await fetch(`${BASE_URL}/produtos/${cod}`);
      const p = await res.json();

      document.getElementById("cod_produto").value = p.cod_produto;
      document.getElementById("nome_produto").value = p.nome_produto;
      document.getElementById("descricao").value = p.descricao ?? "";
      document.getElementById("estoque_produto").value = p.estoque_produto;
    } catch (err) {
      console.error("Erro carregar produto:", err);
    }
  }

  carregarProduto();

  formEditar.addEventListener("submit", async (e) => {
    e.preventDefault();

    const dados = {
      nome_produto: document.getElementById("nome_produto").value,
      descricao: document.getElementById("descricao").value,
      estoque_produto: document.getElementById("estoque_produto").value
    };

    try {
      await fetch(`${BASE_URL}/produtos/${cod}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(dados)
      });

      alert("Produto atualizado com sucesso!");
      window.location.href = "produtos_funcionario.html";
    } catch (err) {
      console.error("Erro editar produto:", err);
      alert("Erro ao editar produto");
    }
  });
}


document.addEventListener("DOMContentLoaded", carregarProdutos);
