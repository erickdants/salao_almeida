import pool from "../db.js";


export const listarProdutos = async (req, res) => {
  const { todos } = req.query;

  try {
    const query = todos === "true"
      ? `SELECT * FROM Produto ORDER BY Cod_produto`
      : `SELECT * FROM Produto WHERE ativo = TRUE ORDER BY Cod_produto`;

    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar produtos:", err);
    res.status(500).send("Erro ao listar produtos");
  }
};


export const cadastrarProduto = async (req, res) => {
  const { nome_produto, descricao, estoque_produto } = req.body;

  try {
    await pool.query(
      `INSERT INTO Produto (Nome_produto, descricao, estoque_produto)
       VALUES ($1, $2, $3)`,
      [nome_produto, descricao, estoque_produto]
    );

    res.status(201).send("Produto cadastrado com sucesso!");
  } catch (err) {
    console.error("Erro cadastrar produto:", err);
    res.status(500).send("Erro ao cadastrar produto");
  }
};


export const buscarProdutoCompleto = async (req, res) => {
  const { cod } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM Produto WHERE Cod_produto = $1`,
      [cod]
    );

    if (!result.rows.length) {
      return res.status(404).send("Produto não encontrado");
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("Erro buscar produto:", err);
    res.status(500).send("Erro ao buscar produto");
  }
};


export const editarProduto = async (req, res) => {
  const { cod } = req.params;
  const { nome_produto, descricao, estoque_produto } = req.body;

  try {
    await pool.query(
      `UPDATE Produto
       SET Nome_produto = $1,
           descricao = $2,
           estoque_produto = $3
       WHERE Cod_produto = $4`,
      [nome_produto, descricao, estoque_produto, cod]
    );

    res.send("Produto atualizado com sucesso!");
  } catch (err) {
    console.error("Erro editar produto:", err);
    res.status(500).send("Erro ao editar produto");
  }
};


export const excluirProduto = async (req, res) => {
  const { cod } = req.params;

  try {
    await pool.query(
      `UPDATE Produto SET ativo = FALSE WHERE Cod_produto = $1`,
      [cod]
    );

    res.send("Produto desativado!");
  } catch (err) {
    console.error("Erro desativar produto:", err);
    res.status(500).send("Erro ao desativar produto");
  }
};


export const reativarProduto = async (req, res) => {
  const { cod } = req.params;

  try {
    await pool.query(
      `UPDATE Produto SET ativo = TRUE WHERE Cod_produto = $1`,
      [cod]
    );

    res.send("Produto reativado!");
  } catch (err) {
    console.error("Erro reativar produto:", err);
    res.status(500).send("Erro ao reativar produto");
  }
};

export const listarUtilizacoesProduto = async (req, res) => {
  const { cod } = req.params;

  try {
    const result = await pool.query(
      `
      SELECT
        cod_agenda,
        quant_produto
      FROM Agenda_utilizara_produto
      WHERE cod_produto = $1
      `,
      [cod]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar utilizações do produto:", err);
    res.status(500).send("Erro ao listar utilizações do produto");
  }
};
