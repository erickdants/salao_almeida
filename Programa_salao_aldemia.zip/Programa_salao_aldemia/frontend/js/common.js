const BASE_URL = "http://localhost:3000";

function handleResponse(res) {
  if (!res.ok) return res.json().then(e => Promise.reject(e));
  return res.json();
}

function getAuth() {
  try {
    return JSON.parse(localStorage.getItem("aldemia_user"));
  } catch {
    return null;
  }
}

function requireAuth() {
  const u = getAuth();
  if (!u) {
    window.location.href = "/index.html";
    throw new Error("Não autenticado");
  }
  return u;
}

function showToast(msg) {
  alert(msg); 
}