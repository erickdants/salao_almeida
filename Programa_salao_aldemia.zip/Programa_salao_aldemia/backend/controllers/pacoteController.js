import pool from "../db.js";


export const listarPacotes = async (req, res) => {
  const { todos } = req.query;

  try {
    const query = todos === "true"
      ? `SELECT * FROM Pacote ORDER BY Cod_pacote`
      : `SELECT * FROM Pacote WHERE ativo = TRUE ORDER BY Cod_pacote`;

    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar pacotes:", err);
    res.status(500).send("Erro ao listar pacotes");
  }
};


export const cadastrarPacote = async (req, res) => {
  const { nome_pacote, descricao, estoque_pacote } = req.body;

  try {
    await pool.query(
      `INSERT INTO Pacote (Nome_pacote, descricao, estoque_pacote, ativo)
       VALUES ($1, $2, $3, TRUE)`,
      [nome_pacote, descricao, estoque_pacote]
    );

    res.status(201).send("Pacote cadastrado com sucesso!");
  } catch (err) {
    console.error("Erro cadastrar pacote:", err);
    res.status(500).send("Erro ao cadastrar pacote");
  }
};


export const buscarPacoteCompleto = async (req, res) => {
  const { cod } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM Pacote WHERE Cod_pacote = $1`,
      [cod]
    );

    if (!result.rows.length) {
      return res.status(404).send("Pacote não encontrado");
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("Erro buscar pacote:", err);
    res.status(500).send("Erro ao buscar pacote");
  }
};


export const editarPacote = async (req, res) => {
  const { cod } = req.params;
  const { nome_pacote, descricao, estoque_pacote } = req.body;

  try {
    await pool.query(
      `UPDATE Pacote
       SET Nome_pacote = $1,
           descricao = $2,
           estoque_pacote = $3
       WHERE Cod_pacote = $4`,
      [nome_pacote, descricao, estoque_pacote, cod]
    );

    res.send("Pacote atualizado com sucesso!");
  } catch (err) {
    console.error("Erro editar pacote:", err);
    res.status(500).send("Erro ao editar pacote");
  }
};


export const excluirPacote = async (req, res) => {
  const { cod } = req.params;

  try {
    await pool.query(
      `UPDATE Pacote SET ativo = FALSE WHERE Cod_pacote = $1`,
      [cod]
    );

    res.send("Pacote desativado!");
  } catch (err) {
    console.error("Erro desativar pacote:", err);
    res.status(500).send("Erro ao desativar pacote");
  }
};


export const reativarPacote = async (req, res) => {
  const { cod } = req.params;

  try {
    await pool.query(
      `UPDATE Pacote SET ativo = TRUE WHERE Cod_pacote = $1`,
      [cod]
    );

    res.send("Pacote reativado!");
  } catch (err) {
    console.error("Erro reativar pacote:", err);
    res.status(500).send("Erro ao reativar pacote");
  }
};

export const listarUtilizacoesPacote = async (req, res) => {
  const { cod } = req.params;

  try {
    const result = await pool.query(
      `
      SELECT
        cod_agenda,
        quant_pacote
      FROM Agenda_utilizara_pacote
      WHERE cod_pacote = $1
      `,
      [cod]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar utilizações do pacote:", err);
    res.status(500).send("Erro ao listar utilizações do pacote");
  }
};
