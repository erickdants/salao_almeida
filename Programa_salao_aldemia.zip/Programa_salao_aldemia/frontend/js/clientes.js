const BASE_URL = "http://localhost:3000";


async function carregarClientes() {
  const tabela = document.querySelector("#tabelaClientes tbody");
  if (!tabela) return;

  try {
    const res = await fetch(`${BASE_URL}/clientes`);
    const clientes = await res.json();

    tabela.innerHTML = "";

    clientes.forEach((cli) => {
      tabela.innerHTML += `
        <tr>
          <td>${cli.cod_cli}</td>
          <td>${cli.nome_cli}</td>
          <td>${cli.cidade_cli ?? ""}</td>
          <td>${cli.idade_cli ?? ""}</td>
          <td>${cli.rua_cli ?? ""}</td>
          <td>${cli.bairro_cli ?? ""}</td>
          <td>${cli.estado_cli ?? ""}</td>
          <td>
            <button class="btn btn-sm btn-primary" onclick="irParaEditar(${cli.cod_cli})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="excluirCliente(${cli.cod_cli})">Excluir</button>
          </td>
        </tr>
      `;
    });
  } catch (err) {
    console.error("Erro ao listar clientes:", err);
  }
}

document.addEventListener("DOMContentLoaded", carregarClientes);


function irParaEditar(id) {
  
  localStorage.setItem("cliente_editar_id", id);
  window.location.href = "cliente_editar.html";
}


async function excluirCliente(id) {
  if (!confirm("Deseja excluir o cliente?")) return;

  try {
    await fetch(`${BASE_URL}/clientes/${id}`, {
      method: "DELETE",
    });

    alert("Cliente excluído!");
    carregarClientes();

  } catch (err) {
    console.error("Erro ao excluir:", err);
  }
}


function addFicha() {
  const box = document.getElementById("listaFicha");
  if (!box) return;
  box.innerHTML += `<input class="form-control mt-2" name="ficha[]" placeholder="Digite aqui...">`;
}

function addHistorico() {
  const box = document.getElementById("listaHistorico");
  if (!box) return;
  box.innerHTML += `<input class="form-control mt-2" name="historico[]" placeholder="Digite aqui...">`;
}

function addCuidados() {
  const box = document.getElementById("listaCuidados");
  if (!box) return;
  box.innerHTML += `<input class="form-control mt-2" name="cuidados[]" placeholder="Digite aqui...">`;
}

function addExame() {
  const box = document.getElementById("listaExame");
  if (!box) return;
  box.innerHTML += `<input class="form-control mt-2" name="exame[]" placeholder="Digite aqui...">`;
}


function isChecked(id) {
  const el = document.getElementById(id);
  return !!(el && el.checked);
}

function valueOrNull(id) {
  const el = document.getElementById(id);
  if (!el) return null;
  const v = el.value;
  return v === "" ? null : v;
}


function montarObjetoClienteCompleto() {
  
  const cliente = {
    nome_cli: valueOrNull("nome_cli"),
    idade_cli: valueOrNull("idade_cli"),
    rua_cli: valueOrNull("rua_cli"),
    bairro_cli: valueOrNull("bairro_cli"),
    cidade_cli: valueOrNull("cidade_cli"),
    estado_cli: valueOrNull("estado_cli"),
  };

  
  const anamnese_ficha = {
    queixa_pincipal: valueOrNull("queixa_principal"),
    alteracao_acomete_corpo: isChecked("alteracao_acomete_corpo"),
    alteracao_acomete_corpo_afirmativo: valueOrNull("alteracao_acomete_corpo_afirmativo"),
    tempo_alteracao: valueOrNull("tempo_alteracao"),
    problema_esta: valueOrNull("problema_esta"),
    cabelo_ficou: valueOrNull("cabelo_ficou"),
    alteracao_cabelo: valueOrNull("alteracao_cabelo"),
    teve_outras_crises: isChecked("teve_outras_crises"),
    quando_teve_outras_crises: valueOrNull("quando_teve_outras_crises"),
    relatorio: valueOrNull("relatorio")
  };

  
  const anamnese_historico_pessoal = {
    alguma_doenca: isChecked("alguma_doenca"),
    qual_doenca: valueOrNull("qual_doenca"),
    frequencia_modo_lavagem_cabelo: valueOrNull("frequencia_modo_lavagem_cabelo"),
    cosmeticos_utilizados: valueOrNull("cosmeticos_utilizados"),
    alergia_cosmetico_medicamento: isChecked("alergia_cosmetico_medicamento"),
    qual_alergia_cosmetico_medicamento: valueOrNull("qual_alergia_cosmetico_medicamento"),
    parente_com_calvicie: isChecked("parente_com_calvicie")
  };

  
  const anamnese_cuidados_cabelo = {
    faz_quimica: isChecked("faz_quimica"),
    qual_quimica: valueOrNull("qual_quimica"),
    frequencia_quimica: valueOrNull("frequencia_quimica"),
    utiliza_acessorio: valueOrNull("utiliza_acessorio")
  };

  
  const anamnese_exame_fisico = {
    couro_capiludo_apresenta: valueOrNull("couro_capiludo_apresenta"),
    presenca_couro_capiludo: valueOrNull("presenca_couro_capiludo"),
    comprimento_cabelo_igual: isChecked("comprimento_cabelo_igual"),
    cabelo_possui: valueOrNull("cabelo_possui"),
    pontas_cabelo: isChecked("pontas_cabelo"),
    fios_encontrados: valueOrNull("fios_encontrados"),
    cor_cabelo: valueOrNull("cor_cabelo"),
    natural_cabelo: isChecked("natural_cabelo"),
    tipo_cabelo: valueOrNull("tipo_cabelo"),
    texturizacao_cabelo: valueOrNull("texturizacao_cabelo"),
    curvatura_cabelo: valueOrNull("curvatura_cabelo"),
    espessura_cabelo: valueOrNull("espessura_cabelo"),
    densidade_cabelo: valueOrNull("densidade_cabelo"),
    porosidade_cabelo: valueOrNull("porosidade_cabelo"),
    elasticidade_cabelo: valueOrNull("elasticidade_cabelo"),
    complicacoes_cabelo: valueOrNull("complicacoes_cabelo"),
    observacao_complementar: valueOrNull("observacao_complementar")
  };

  return {
    cliente,
    anamnese_ficha,
    anamnese_historico_pessoal,
    anamnese_cuidados_cabelo,
    anamnese_exame_fisico
  };
}


async function initCadastrarCliente() {
  const form = document.getElementById("formCadastrarCliente");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = montarObjetoClienteCompleto();

    try {
      const res = await fetch(`${BASE_URL}/clientes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("Erro ao cadastrar (server):", res.status, text);
        alert("Erro ao cadastrar cliente - ver console do servidor.");
        return;
      }

      alert("Cliente cadastrado com sucesso!");
      window.location.href = "clientes.html";
    } catch (err) {
      console.error("Erro ao cadastrar:", err);
      alert("Erro ao cadastrar cliente (front).");
    }
  });
}
initCadastrarCliente();


async function carregarClienteEdicao() {
  const id = localStorage.getItem("cliente_editar_id");
  const form = document.getElementById("formEditarCliente");
  if (!form) return;

  if (!id) {
    console.warn("cliente_editar_id não encontrado em localStorage");
    return;
  }

  try {
    const res = await fetch(`${BASE_URL}/clientes/${id}/completo`);
    if (!res.ok) {
      console.error("Erro ao buscar cliente completo:", res.status);
      return;
    }
    const data = await res.json();

    
    document.getElementById("Cod_cli").value = data.cliente.cod_cli ?? "";
    document.getElementById("nome_cli").value = data.cliente.nome_cli ?? "";
    document.getElementById("idade_cli").value = data.cliente.idade_cli ?? "";
    document.getElementById("rua_cli").value = data.cliente.rua_cli ?? "";
    document.getElementById("cidade_cli").value = data.cliente.cidade_cli ?? "";
    document.getElementById("bairro_cli").value = data.cliente.bairro_cli ?? "";
    document.getElementById("estado_cli").value = data.cliente.estado_cli ?? "";

    
    const ficha = Array.isArray(data.anamnese_ficha) && data.anamnese_ficha.length ? data.anamnese_ficha[0] : null;
    if (ficha) {
      document.getElementById("queixa_principal").value = ficha.queixa_pincipal ?? ficha.queixa_principal ?? "";
      document.getElementById("alteracao_acomete_corpo").checked = !!ficha.alteracao_acomete_corpo;
      document.getElementById("alteracao_acomete_corpo_afirmativo").value = ficha.alteracao_acomete_corpo_afirmativo ?? ficha.descricao ?? "";
      document.getElementById("tempo_alteracao").value = ficha.tempo_alteracao ?? "";
      document.getElementById("problema_esta").value = ficha.problema_esta ?? "";
      document.getElementById("cabelo_ficou").value = ficha.cabelo_ficou ?? "";
      document.getElementById("alteracao_cabelo").value = ficha.alteracao_cabelo ?? "";
      document.getElementById("teve_outras_crises").checked = !!ficha.teve_outras_crises;
      document.getElementById("quando_teve_outras_crises").value = ficha.quando_teve_outras_crises ?? "";
      document.getElementById("relatorio").value = ficha.relatorio ?? "";
    }

   
    const historico = Array.isArray(data.anamnese_historico_pessoal) && data.anamnese_historico_pessoal.length ? data.anamnese_historico_pessoal[0] : null;
    if (historico) {
      document.getElementById("alguma_doenca").checked = !!historico.alguma_doenca;
      document.getElementById("qual_doenca").value = historico.qual_doenca ?? historico.descricao ?? "";
      document.getElementById("frequencia_modo_lavagem_cabelo").value = historico.frequencia_modo_lavagem_cabelo ?? "";
      document.getElementById("cosmeticos_utilizados").value = historico.cosmeticos_utilizados ?? "";
      document.getElementById("alergia_cosmetico_medicamento").checked = !!historico.alergia_cosmetico_medicamento;
      document.getElementById("qual_alergia_cosmetico_medicamento").value = historico.qual_alergia_cosmetico_medicamento ?? "";
      document.getElementById("parente_com_calvicie").checked = !!historico.parente_com_calvicie;
    }

    
    const cuidados = Array.isArray(data.anamnese_cuidados_cabelo) && data.anamnese_cuidados_cabelo.length ? data.anamnese_cuidados_cabelo[0] : null;
    if (cuidados) {
      document.getElementById("faz_quimica").checked = !!cuidados.faz_quimica;
      document.getElementById("qual_quimica").value = cuidados.qual_quimica ?? cuidados.descricao ?? "";
      document.getElementById("frequencia_quimica").value = cuidados.frequencia_quimica ?? "";
      document.getElementById("utiliza_acessorio").value = cuidados.utiliza_acessorio ?? "";
    }

    
    const exame = Array.isArray(data.anamnese_exame_fisico) && data.anamnese_exame_fisico.length ? data.anamnese_exame_fisico[0] : null;
    if (exame) {
      document.getElementById("couro_capiludo_apresenta").value = exame.couro_capiludo_apresenta ?? exame.Couro_capiludo_apresenta ?? exame.descricao ?? "";
      document.getElementById("presenca_couro_capiludo").value = exame.presenca_couro_capiludo ?? exame.Presenca_couro_capiludo ?? "";
      document.getElementById("comprimento_cabelo_igual").checked = !!(exame.Comprimento_cabelo_igual || exame.Comprimento_cabelo_igual === true);
      document.getElementById("cabelo_possui").value = exame.Cabelo_possui ?? exame.cabelo_possui ?? "";
      document.getElementById("pontas_cabelo").checked = !!exame.Pontas_cabelo;
      document.getElementById("fios_encontrados").value = exame.Fios_encontrados ?? "";
      document.getElementById("cor_cabelo").value = exame.Cor_cabelo ?? exame.cor_cabelo ?? "";
      document.getElementById("natural_cabelo").checked = !!exame.Natural_cabelo;
      document.getElementById("tipo_cabelo").value = exame.Tipo_cabelo ?? exame.tipo_cabelo ?? "";
      document.getElementById("texturizacao_cabelo").value = exame["Texturização_cabelo"] ?? exame.texturizacao_cabelo ?? "";
      document.getElementById("curvatura_cabelo").value = exame.Curvatura_cabelo ?? exame.curvatura_cabelo ?? "";
      document.getElementById("espessura_cabelo").value = exame.Espessura_cabelo ?? exame.espessura_cabelo ?? "";
      document.getElementById("densidade_cabelo").value = exame.Densidade_cabelo ?? exame.densidade_cabelo ?? "";
      document.getElementById("porosidade_cabelo").value = exame.Porosidade_cabelo ?? exame.porosidade_cabelo ?? "";
      document.getElementById("elasticidade_cabelo").value = exame.Elasticidade_cabelo ?? exame.elasticidade_cabelo ?? "";
      document.getElementById("complicacoes_cabelo").value = exame["Complicações_cabelo"] ?? exame.complicacoes_cabelo ?? "";
      document.getElementById("observacao_complementar").value = exame.Observacao_complementar ?? exame.observacao_complementar ?? "";
    }

  } catch (err) {
    console.error("Erro ao carregar cliente:", err);
  }
}

document.addEventListener("DOMContentLoaded", carregarClienteEdicao);


function initEditarCliente() {
  const form = document.getElementById("formEditarCliente");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const id = localStorage.getItem("cliente_editar_id");
    if (!id) {
      alert("ID do cliente não encontrado.");
      return;
    }

    const payload = montarObjetoClienteCompleto();

    try {
      const res = await fetch(`${BASE_URL}/clientes/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const text = await res.text();
        console.error("Erro ao atualizar (server):", res.status, text);
        alert("Erro ao atualizar cliente - veja console do servidor.");
        return;
      }

      alert("Cliente atualizado com sucesso!");
      window.location.href = "clientes.html";

    } catch (err) {
      console.error("Erro ao editar:", err);
      alert("Erro ao editar cliente (front).");
    }
  });
}
initEditarCliente();
