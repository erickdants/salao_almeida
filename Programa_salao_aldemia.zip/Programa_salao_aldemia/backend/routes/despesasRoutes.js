import express from "express";
import {
  listarDespesas,
  cadastrarDespesa,
  buscarDespesa,
  editarDespesa,
  excluirDespesa
} from "../controllers/despesasController.js";

const router = express.Router();

router.get("/", listarDespesas);
router.post("/", cadastrarDespesa);
router.get("/:id", buscarDespesa);
router.put("/:id", editarDespesa);
router.delete("/:id", excluirDespesa);

export default router;
