
import express from "express";
import {
  listarAgendas,
  cadastrarAgenda,
  buscarAgendaCompleta,
  editarAgenda,
  excluirAgenda
} from "../controllers/agendaController.js";

const router = express.Router();

router.get("/", listarAgendas);
router.post("/", cadastrarAgenda);
router.get("/:cod/completo", buscarAgendaCompleta);
router.put("/:cod", editarAgenda);
router.delete("/:cod", excluirAgenda);

export default router;
