
import pool from "../db.js";


export const listarFinancas = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT * FROM Financas
      ORDER BY Ano DESC, Mes DESC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro ao listar finanças:", err);
    res.status(500).send("Erro ao listar finanças");
  }
};


export const cadastrarFinanca = async (req, res) => {
  const { mes, ano, despesas } = req.body;

  try {
    
    const proventosQuery = await pool.query(`
      SELECT COALESCE(SUM(valor_total), 0) AS total
      FROM Vendas
      WHERE EXTRACT(MONTH FROM data_venda) = $1
      AND EXTRACT(YEAR FROM data_venda) = $2
    `, [mes, ano]);

    
    const despesasQuery = await pool.query(`
      SELECT COALESCE(SUM(valor), 0) AS total
      FROM Despesas
      WHERE EXTRACT(MONTH FROM dia_despesa) = $1
      AND EXTRACT(YEAR FROM dia_despesa) = $2
    `, [mes, ano]);

    const proventos = Number(proventosQuery.rows[0].total);
    const despesasTotais = Number(despesasQuery.rows[0].total) + Number(despesas || 0);
    const lucro = proventos - despesasTotais;

    await pool.query(`
      INSERT INTO Financas (Mes, Ano, lucro, despesas, proventos)
      VALUES ($1, $2, $3, $4, $5)
    `, [mes, ano, lucro, despesasTotais, proventos]);

    res.status(201).send("Finança mensal cadastrada com sucesso!");
  } catch (err) {
    console.error("Erro ao cadastrar finança:", err);
    res.status(500).send("Erro ao cadastrar finança");
  }
};

export const buscarFinanca = async (req, res) => {
  const { mes, ano } = req.params;
  try {
    const result = await pool.query(
      `SELECT * FROM Financas WHERE Mes = $1 AND Ano = $2`,
      [mes, ano]
    );
    if (!result.rows.length) return res.status(404).send("Finança não encontrada");
    res.json(result.rows[0]);
  } catch (err) {
    console.error("Erro buscar finança:", err);
    res.status(500).send("Erro ao buscar finança");
  }
};

export const editarFinanca = async (req, res) => {
  const { mes, ano } = req.params;
  const { despesas } = req.body;

  try {
    const proventosQuery = await pool.query(`
      SELECT COALESCE(SUM(valor_total), 0) AS total
      FROM Vendas
      WHERE EXTRACT(MONTH FROM data_venda) = $1
      AND EXTRACT(YEAR FROM data_venda) = $2
    `, [mes, ano]);

    const despesasQuery = await pool.query(`
      SELECT COALESCE(SUM(valor), 0) AS total
      FROM Despesas
      WHERE EXTRACT(MONTH FROM dia_despesa) = $1
      AND EXTRACT(YEAR FROM dia_despesa) = $2
    `, [mes, ano]);

    const proventos = Number(proventosQuery.rows[0].total);
    const despesasTotais = Number(despesasQuery.rows[0].total) + Number(despesas || 0);
    const lucro = proventos - despesasTotais;

    await pool.query(`
      UPDATE Financas
      SET lucro=$1, despesas=$2, proventos=$3
      WHERE Mes=$4 AND Ano=$5
    `, [lucro, despesasTotais, proventos, mes, ano]);

    res.send("Finança mensal atualizada com sucesso!");
  } catch (err) {
    console.error("Erro editar finança:", err);
    res.status(500).send("Erro ao editar finança");
  }
};

export const excluirFinanca = async (req, res) => {
  const { mes, ano } = req.params;
  try {
    await pool.query(`DELETE FROM Financas WHERE Mes=$1 AND Ano=$2`, [mes, ano]);
    res.send("Finança excluída com sucesso!");
  } catch (err) {
    console.error("Erro excluir finança:", err);
    res.status(500).send("Erro ao excluir finança");
  }
};
