import express from "express";
import {
  listarServicos,
  cadastrarServico,
  atualizarServico,
  excluirServico
} from "../controllers/servicoController.js";

const router = express.Router();

router.get("/", listarServicos);
router.post("/", cadastrarServico);
router.put("/:id", atualizarServico);
router.delete("/:id", excluirServico);

export default router;
