

document.addEventListener("DOMContentLoaded", () => {
  try {
    const user = requireAuth(); 
    const spanNome = document.getElementById("userName");

    
    if (user?.nome_usuario || user?.nome || user?.ID_usuario) {
      spanNome.textContent = user.nome_usuario || user.nome || user.ID_usuario;
    } else {
      spanNome.textContent = "Funcionário";
    }
  } catch (err) {
    console.warn("Usuário não autenticado:", err);
  }
});


document.getElementById("logoutBtn").addEventListener("click", () => {
  if (confirm("Deseja sair da conta?")) {
    localStorage.removeItem("aldemia_user");
    localStorage.removeItem("nome_usuario");
    window.location.href = "index.html";
  }
});
