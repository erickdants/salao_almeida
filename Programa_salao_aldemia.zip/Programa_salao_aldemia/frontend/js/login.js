// login.js
document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const ID_usuario = document.getElementById("id_usuario").value.trim();
  const senha_usuario = document.getElementById("senha").value;

  try {
    const res = await fetch(`${BASE_URL}/usuarios/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ID_usuario, senha_usuario })
    });
    const data = await handleResponse(res);
    // assumimos que o backend retorna { sucesso: true, usuario: {...} } ou { usuario: { id_usuario, ... } }
    const usuario = data.usuario || data;
    localStorage.setItem("aldemia_user", JSON.stringify(usuario));
    window.location.href = "dashboard.html";
  } catch (err) {
    console.error(err);
    showToast(err.error || err.mensagem || "Falha ao autenticar");
  }
});
