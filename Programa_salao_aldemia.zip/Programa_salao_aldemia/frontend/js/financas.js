const BASE_URL = "http://localhost:3000";


async function carregarFinancas() {
  const tabela = document.querySelector("#tabelaFinancas tbody");
  if (!tabela) return;

  const res = await fetch(`${BASE_URL}/financas`);
  const financas = await res.json();

  tabela.innerHTML = "";
  financas.forEach(f => {
    tabela.innerHTML += `
      <tr>
        <td>${String(f.mes).padStart(2, "0")}/${f.ano}</td>
        <td>R$ ${parseFloat(f.proventos).toFixed(2)}</td>
        <td>R$ ${parseFloat(f.despesas).toFixed(2)}</td>
        <td><b>R$ ${parseFloat(f.lucro).toFixed(2)}</b></td>
        <td>
          <button class="btn btn-sm btn-primary" onclick="editarFinanca(${f.mes}, ${f.ano})">Editar</button>
          <button class="btn btn-sm btn-danger" onclick="excluirFinanca(${f.mes}, ${f.ano})">Excluir</button>
        </td>
      </tr>
    `;
  });
}
document.addEventListener("DOMContentLoaded", carregarFinancas);


function editarFinanca(mes, ano) {
  localStorage.setItem("financa_editar_mes", mes);
  localStorage.setItem("financa_editar_ano", ano);
  window.location.href = "financa_editar.html";
}


async function initCadastrarFinanca() {
  const form = document.getElementById("formCadastrarFinanca");
  if (!form) return;

  const hoje = new Date();
  document.getElementById("mes").value = hoje.getMonth() + 1;
  document.getElementById("ano").value = hoje.getFullYear();

  form.addEventListener("submit", async e => {
    e.preventDefault();
    const payload = {
      mes: Number(document.getElementById("mes").value),
      ano: Number(document.getElementById("ano").value),
      despesas: parseFloat(document.getElementById("despesas").value || 0)
    };

    const res = await fetch(`${BASE_URL}/financas`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      alert("Finança mensal cadastrada com sucesso!");
      window.location.href = "financas.html";
    } else alert("Erro ao cadastrar finança!");
  });
}
initCadastrarFinanca();


async function carregarFinancaEdicao() {
  const mes = localStorage.getItem("financa_editar_mes");
  const ano = localStorage.getItem("financa_editar_ano");
  const form = document.getElementById("formEditarFinanca");
  if (!form || !mes || !ano) return;

  const res = await fetch(`${BASE_URL}/financas/${mes}/${ano}`);
  const f = await res.json();

  document.getElementById("mes").value = f.mes;
  document.getElementById("ano").value = f.ano;
  document.getElementById("despesas").value = f.despesas ?? 0;
}
document.addEventListener("DOMContentLoaded", carregarFinancaEdicao);


async function initEditarFinanca() {
  const form = document.getElementById("formEditarFinanca");
  if (!form) return;

  form.addEventListener("submit", async e => {
    e.preventDefault();

    const mes = document.getElementById("mes").value;
    const ano = document.getElementById("ano").value;
    const payload = { despesas: parseFloat(document.getElementById("despesas").value || 0) };

    const res = await fetch(`${BASE_URL}/financas/${mes}/${ano}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      alert("Finança mensal atualizada!");
      window.location.href = "financas.html";
    } else alert("Erro ao atualizar finança!");
  });
}
initEditarFinanca();


async function excluirFinanca(mes, ano) {
  if (!confirm("Deseja excluir esta finança mensal?")) return;
  const res = await fetch(`${BASE_URL}/financas/${mes}/${ano}`, { method: "DELETE" });
  if (res.ok) {
    alert("Finança excluída!");
    carregarFinancas();
  } else alert("Erro ao excluir finança!");
}
