
import pool from "../db.js";


export const listarDespesas = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT * FROM Despesas ORDER BY Dia_despesa DESC, Cod_despesa DESC
    `);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar despesas:", err);
    res.status(500).send("Erro ao listar despesas");
  }
};


export const cadastrarDespesa = async (req, res) => {
  const { valor, dia_despesa, descricao } = req.body;

  try {
    await pool.query(
      `INSERT INTO Despesas (Valor, Dia_despesa, Descricao)
       VALUES ($1, $2, $3)`,
      [valor, dia_despesa || new Date(), descricao]
    );
    res.status(201).send("Despesa cadastrada com sucesso!");
  } catch (err) {
    console.error("Erro cadastrar despesa:", err);
    res.status(500).send("Erro ao cadastrar despesa");
  }
};


export const buscarDespesa = async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      `SELECT * FROM Despesas WHERE Cod_despesa = $1`,
      [id]
    );
    if (result.rows.length === 0)
      return res.status(404).send("Despesa não encontrada");
    res.json(result.rows[0]);
  } catch (err) {
    console.error("Erro buscar despesa:", err);
    res.status(500).send("Erro ao buscar despesa");
  }
};


export const editarDespesa = async (req, res) => {
  const { id } = req.params;
  const { valor, dia_despesa, descricao } = req.body;

  try {
    await pool.query(
      `UPDATE Despesas
       SET Valor = $1, Dia_despesa = $2, Descricao = $3
       WHERE Cod_despesa = $4`,
      [valor, dia_despesa, descricao, id]
    );
    res.send("Despesa atualizada com sucesso!");
  } catch (err) {
    console.error("Erro editar despesa:", err);
    res.status(500).send("Erro ao editar despesa");
  }
};


export const excluirDespesa = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query(`DELETE FROM Despesas WHERE Cod_despesa = $1`, [id]);
    res.send("Despesa excluída com sucesso!");
  } catch (err) {
    console.error("Erro excluir despesa:", err);
    res.status(500).send("Erro ao excluir despesa");
  }
};
