import express from "express";
import {
  listarVendas,
  registrarVenda,
  excluirVenda
} from "../controllers/vendasController.js";

const router = express.Router();

router.get("/", listarVendas);
router.post("/", registrarVenda);
router.delete("/:id", excluirVenda);

export default router;