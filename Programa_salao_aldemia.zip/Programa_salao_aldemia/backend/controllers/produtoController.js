import pool from "../db.js";

export const listarProdutos = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM Produto ORDER BY id_produto ASC");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const cadastrarProduto = async (req, res) => {
  const { nome_produto, preco_produto, quantidade_produto } = req.body;
  try {
    const result = await pool.query(
      "INSERT INTO Produto (nome_produto, preco_produto, quantidade_produto) VALUES ($1, $2, $3) RETURNING *",
      [nome_produto, preco_produto, quantidade_produto]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const atualizarProduto = async (req, res) => {
  const { id } = req.params;
  const { nome_produto, preco_produto, quantidade_produto } = req.body;
  try {
    const result = await pool.query(
      "UPDATE Produto SET nome_produto=$1, preco_produto=$2, quantidade_produto=$3 WHERE id_produto=$4 RETURNING *",
      [nome_produto, preco_produto, quantidade_produto, id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const excluirProduto = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM Produto WHERE id_produto=$1", [id]);
    res.json({ mensagem: "Produto removido com sucesso!" });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};
