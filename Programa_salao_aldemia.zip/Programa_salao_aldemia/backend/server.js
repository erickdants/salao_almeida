import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import usuarioRoutes from "./routes/usuarioRoutes.js";
import clienteRoutes from "./routes/clienteRoutes.js";
import agendaRoutes from "./routes/agendaRoutes.js";
import servicoRoutes from "./routes/servicoRoutes.js";
import produtoRoutes from "./routes/produtoRoutes.js";
import vendasRoutes from "./routes/vendasRoutes.js";
import funcionarioRoutes from "./routes/funcionarioRoutes.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/clientes", clienteRoutes);
app.use("/agenda", agendaRoutes);
app.use("/servicos", servicoRoutes);
app.use("/produtos", produtoRoutes);
app.use("/vendas", vendasRoutes);
app.use("/usuarios", usuarioRoutes);
app.use("/funcionarios", funcionarioRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));
