import express from "express";
import {
  listarPacotes,
  cadastrarPacote,
  buscarPacoteCompleto,
  editarPacote,
  excluirPacote,
  listarUtilizacoesPacote,
  reativarPacote
} from "../controllers/pacoteController.js";

const router = express.Router();

router.get("/", listarPacotes);                 
router.post("/", cadastrarPacote);
router.get("/:cod", buscarPacoteCompleto);
router.put("/:cod", editarPacote);
router.delete("/:cod", excluirPacote);          
router.put("/:cod/reativar", reativarPacote);   
router.get("/:cod/utilizacoes", listarUtilizacoesPacote);


export default router;
