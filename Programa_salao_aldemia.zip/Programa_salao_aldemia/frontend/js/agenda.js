// agenda.js
try { requireAuth(); } catch (e) {}

const formA = document.getElementById("agendaForm");
const tbodyA = document.getElementById("agendaTbody");
const inCodCli = document.getElementById("cod_cli");
const inData = document.getElementById("data_agenda");
const inAgendaId = document.getElementById("agendaId");

async function listarAgenda() {
  try {
    const res = await fetch(`${BASE_URL}/agenda`);
    const data = await handleResponse(res);
    tbodyA.innerHTML = "";
    data.forEach(a => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${a.cod_agenda ?? a.Cod_agenda ?? ""}</td>
        <td>${a.Cod_cli ?? a.cod_cli ?? ""}</td>
        <td>${a.data_agenda ?? a.Data_agenda ?? ""}</td>
        <td>
          <button class="btn btn-sm btn-primary me-1" data-id="${a.cod_agenda ?? a.Cod_agenda ?? ""}" data-action="edit">Editar</button>
          <button class="btn btn-sm btn-danger" data-id="${a.cod_agenda ?? a.Cod_agenda ?? ""}" data-action="del">Excluir</button>
        </td>
      `;
      tbodyA.appendChild(tr);
    });
    tbodyA.querySelectorAll("button").forEach(b=>b.addEventListener("click", onAction));
  } catch (err) {
    console.error(err); showToast("Erro ao carregar agenda");
  }
}

async function onAction(e) {
  const id = e.currentTarget.dataset.id;
  const action = e.currentTarget.dataset.action;
  if (action === "edit") {
    const row = e.currentTarget.closest("tr");
    inAgendaId.value = id;
    inCodCli.value = row.cells[1].innerText;
    inData.value = row.cells[2].innerText;
  } else {
    if (!confirm("Confirma exclusão?")) return;
    try {
      const res = await fetch(`${BASE_URL}/agenda/${encodeURIComponent(id)}`, { method: "DELETE" });
      await handleResponse(res);
      showToast("Agendamento excluído");
      listarAgenda();
    } catch (err) { console.error(err); showToast("Erro ao excluir"); }
  }
}

formA.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = { Cod_cli: inCodCli.value.trim(), Data_agenda: inData.value };
  const id = inAgendaId.value;
  try {
    if (id) {
      const res = await fetch(`${BASE_URL}/agenda/${encodeURIComponent(id)}`, {
        method: "PUT", headers: {"Content-Type":"application/json"}, body: JSON.stringify(payload)
      });
      await handleResponse(res);
      showToast("Agendamento atualizado");
      inAgendaId.value = "";
    } else {
      const res = await fetch(`${BASE_URL}/agenda`, {
        method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(payload)
      });
      await handleResponse(res);
      showToast("Agendamento criado");
    }
    formA.reset(); listarAgenda();
  } catch (err) {
    console.error(err); showToast("Erro salvando agendamento");
  }
});

document.getElementById("backDash").addEventListener("click", ()=> window.location.href="dashboard.html");

listarAgenda();
