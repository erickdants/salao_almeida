
import express from "express";
import {
  listarVendas,
  buscarVendaCompleta,
  cadastrarVenda,
  editarVenda,
  excluirVenda
} from "../controllers/vendasFuncionarioController.js";

const router = express.Router();


router.get("/funcionario/:cod_f", listarVendas);
router.get("/:cod_vendas/completo", buscarVendaCompleta);
router.post("/", cadastrarVenda);
router.put("/:cod_vendas", editarVenda);
router.delete("/:cod_vendas", excluirVenda);

export default router;
