const BASE_URL = "http://localhost:3000";


async function carregarFuncionarios() {
  const tabela = document.querySelector("#tabelaFuncionarios tbody");
  if (!tabela) return;

  try {
    const res = await fetch(`${BASE_URL}/funcionarios`);
    const funcionarios = await res.json();

    tabela.innerHTML = "";

    funcionarios.forEach((f) => {
      tabela.innerHTML += `
        <tr>
          <td>${f.cod_f ?? ""}</td>
          <td>${f.id_usuario ?? ""}</td>
          <td>${f.nome_usuario ?? ""}</td>
          <td>${f.status ?? ""}</td>
          <td>${f.ch ?? ""}</td>
          <td>
            <button class="btn btn-sm btn-primary" onclick="irParaEditarFuncionario(${f.cod_f})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="excluirFuncionario(${f.cod_f})">Excluir</button>
          </td>
        </tr>
      `;
    });
  } catch (err) {
    console.error("Erro ao listar funcionários:", err);
  }
}

document.addEventListener("DOMContentLoaded", carregarFuncionarios);


function irParaEditarFuncionario(cod_f) {
  localStorage.setItem("funcionario_editar_cod", cod_f);
  window.location.href = "funcionario_editar.html";
}


async function excluirFuncionario(cod_f) {
  if (!confirm("Deseja excluir este funcionário?")) return;

  try {
    const res = await fetch(`${BASE_URL}/funcionarios/${cod_f}`, {
      method: "DELETE",
    });

    if (!res.ok) {
      alert("Erro ao excluir funcionário.");
      return;
    }

    alert("Funcionário excluído!");
    carregarFuncionarios();
  } catch (err) {
    console.error("Erro ao excluir funcionário:", err);
  }
}


function createDynamicItem(value = "", placeholder = "", name = "item[]") {
  const wrapper = document.createElement("div");
  wrapper.className = "d-flex gap-2 mb-2";

  const input = document.createElement("input");
  input.type = "text";
  input.className = "form-control";
  input.placeholder = placeholder;
  input.value = value;
  input.name = name;

  const btn = document.createElement("button");
  btn.type = "button";
  btn.className = "btn btn-outline-danger";
  btn.textContent = "Remover";
  btn.onclick = () => wrapper.remove();

  wrapper.appendChild(input);
  wrapper.appendChild(btn);

  return wrapper;
}

function addContato(value = "") {
  document.getElementById("listaContatos").appendChild(
    createDynamicItem(value, "Contato (telefone, email...)", "contato[]")
  );
}

function addEspecializacao(value = "") {
  document.getElementById("listaEspecializacoes").appendChild(
    createDynamicItem(value, "Ex.: Cabeleireiro, Manicure...", "especializacao[]")
  );
}


function valueOrNull(id) {
  const el = document.getElementById(id);
  if (!el) return null;
  return el.value === "" ? null : el.value;
}

function collectArray(name) {
  return Array.from(document.querySelectorAll(`input[name="${name}"]`))
    .map((i) => i.value.trim())
    .filter((v) => v.length > 0);
}


function montarObjetoFuncionario() {
  return {
    funcionario: {
      id_usuario: document.getElementById("id_usuario")?.value || null,
      nome_usuario: valueOrNull("nome_usuario"),
      senha_usuario: valueOrNull("senha_usuario"),
      status: valueOrNull("Status"),
      ch: Number(valueOrNull("CH"))
    },
    contatos: collectArray("contato[]"),
    especializacoes: collectArray("especializacao[]")
  };
}



async function initCadastrarFuncionario() {
  const form = document.getElementById("formCadastrarFuncionario");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const payload = montarObjetoFuncionario();

    try {
      const res = await fetch(`${BASE_URL}/funcionarios`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        alert("Erro ao cadastrar funcionário");
        return;
      }

      alert("Funcionário cadastrado!");
      window.location.href = "funcionarios.html";
    } catch (err) {
      console.error("Erro ao cadastrar:", err);
    }
  });
}
initCadastrarFuncionario();


async function carregarFuncionarioEdicao() {
  const cod = localStorage.getItem("funcionario_editar_cod");
  const form = document.getElementById("formEditarFuncionario");
  if (!form) return;

  try {
    const res = await fetch(`${BASE_URL}/funcionarios/${cod}/completo`);
    const data = await res.json();

    document.getElementById("cod_f").value = data.funcionario.cod_f;
    document.getElementById("id_usuario").value = data.funcionario.id_usuario;
    document.getElementById("nome_usuario").value = data.funcionario.nome_usuario;
    document.getElementById("senha_usuario").value = data.funcionario.senha_usuario ?? "";
    document.getElementById("Status").value = data.funcionario.status ?? "";
    document.getElementById("CH").value = data.funcionario.ch ?? "";

    const contatosBox = document.getElementById("listaContatos");
    contatosBox.innerHTML = "";
    (data.contatos ?? []).forEach((c) => addContato(c));

    const espBox = document.getElementById("listaEspecializacoes");
    espBox.innerHTML = "";
    (data.especializacoes ?? []).forEach((e) => addEspecializacao(e));

  } catch (err) {
    console.error("Erro carregar funcionário:", err);
  }
}

document.addEventListener("DOMContentLoaded", carregarFuncionarioEdicao);


function initEditarFuncionario() {
  const form = document.getElementById("formEditarFuncionario");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const cod = localStorage.getItem("funcionario_editar_cod");
    const payload = montarObjetoFuncionario();

    try {
      const res = await fetch(`${BASE_URL}/funcionarios/${cod}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        alert("Erro ao editar funcionário");
        return;
      }

      alert("Funcionário atualizado!");
      window.location.href = "funcionarios.html";
    } catch (err) {
      console.error("Erro editar funcionário:", err);
    }
  });
}
initEditarFuncionario();
