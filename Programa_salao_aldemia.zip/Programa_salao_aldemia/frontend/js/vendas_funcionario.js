
const BASE_URL = "http://localhost:3000";


function getAuth() {
  try {
    return JSON.parse(localStorage.getItem("aldemia_user"));
  } catch {
    return null;
  }
}

async function buscarFuncionarioPorUsuario(id_usuario) {
  try {
    const r = await fetch(`${BASE_URL}/funcionarios`);
    if (!r.ok) return null;
    const lista = await r.json();
    const f = lista.find(x => String(x.id_usuario) === String(id_usuario));
    return f ? Number(f.cod_f) : null;
  } catch {
    return null;
  }
}


async function carregarVendas() {
  const tbody = document.querySelector("#tabelaVendas tbody");
  if (!tbody) return;

  const user = getAuth();
  if (!user) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Funcionário não autenticado.</td></tr>`;
    return;
  }

  const id_usuario = user.ID_usuario || user.id_usuario;
  const cod_f = await buscarFuncionarioPorUsuario(id_usuario);
  console.log("Carregando vendas para o funcionário:", cod_f);

  if (!cod_f) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Funcionário não encontrado.</td></tr>`;
    return;
  }

  try {
    const res = await fetch(`${BASE_URL}/vendasFuncionario/funcionario/${cod_f}`);
    if (!res.ok) throw new Error("Erro ao buscar vendas.");

    const vendas = await res.json();
    tbody.innerHTML = "";

    if (!vendas.length) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center">Nenhuma venda encontrada.</td></tr>`;
      return;
    }

    vendas.forEach(v => {
      const d = new Date(v.data_venda);
      const dataBr = `${String(d.getDate()).padStart(2,"0")}/${String(d.getMonth()+1).padStart(2,"0")}/${d.getFullYear()}`; // só data
      tbody.innerHTML += `
        <tr>
          <td>${v.cod_vendas}</td>
          <td>${v.nome_cli ?? ""}</td>
          <td>${v.nome_funcionario ?? ""}</td>
          <td>R$ ${parseFloat(v.valor_total).toFixed(2)}</td>
          <td>${dataBr}</td>
          <td class="text-center">
            <button class="btn btn-sm btn-info me-1" onclick="detalharVenda(${v.cod_vendas})">Detalhes</button>
            <button class="btn btn-sm btn-primary me-1" onclick="editarVenda(${v.cod_vendas})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="excluirVenda(${v.cod_vendas})">Excluir</button>
          </td>
        </tr>
      `;
    });
  } catch (err) {
    console.error("Erro ao listar vendas:", err);
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger">Erro ao carregar vendas.</td></tr>`;
  }
}
document.addEventListener("DOMContentLoaded", carregarVendas);


async function detalharVenda(cod_vendas) {
  try {
    const r = await fetch(`${BASE_URL}/vendasFuncionario/${cod_vendas}/completo`);
    if (!r.ok) throw new Error("Erro ao buscar detalhes.");
    const v = await r.json();

    let html = `
      <p><b>Código:</b> ${v.cod_vendas}</p>
      <p><b>Cliente:</b> ${v.cod_cli ?? ""}</p>
      <p><b>Funcionário:</b> ${v.cod_f ?? ""}</p>
      <p><b>Valor Total:</b> R$ ${parseFloat(v.valor_total).toFixed(2)}</p>
      <p><b>Data da Venda:</b> ${v.data_venda ? new Date(v.data_venda).toLocaleDateString("pt-BR") : "—"}</p>
    `;

    html += `<h5 class="mt-3">Produtos</h5>`;
    html += v.produtos?.length
      ? `<ul>${v.produtos.map(p=>`<li>${p.nome_produto} — Qtd: ${p.quant_vendido_produto}</li>`).join("")}</ul>`
      : `<p>Nenhum produto</p>`;

    html += `<h5 class="mt-3">Serviços</h5>`;
    html += v.servicos?.length
      ? `<ul>${v.servicos.map(s=>`<li>${s.nome_servico} — Qtd: ${s.quant_vendido_servico}</li>`).join("")}</ul>`
      : `<p>Nenhum serviço</p>`;

    html += `<h5 class="mt-3">Pacotes</h5>`;
    html += v.pacotes?.length
      ? `<ul>${v.pacotes.map(p=>`<li>${p.nome_pacote} — Qtd: ${p.quant_vendido_pacote}</li>`).join("")}</ul>`
      : `<p>Nenhum pacote</p>`;

    document.getElementById("detalhesConteudo").innerHTML = html;
    document.getElementById("detalhesVenda").style.display = "block";
    document.getElementById("detalhesVenda").scrollIntoView({ behavior: "smooth" });
  } catch (err) {
    console.error("Erro ao detalhar venda:", err);
    alert("Erro ao carregar detalhes da venda.");
  }
}
function fecharDetalhes() {
  document.getElementById("detalhesVenda").style.display = "none";
  document.getElementById("detalhesConteudo").innerHTML = "";
}


async function excluirVenda(id) {
  if (!confirm("Deseja excluir esta venda?")) return;
  const r = await fetch(`${BASE_URL}/vendasFuncionario/${id}`, { method: "DELETE" });
  if (r.ok) {
    alert("Venda excluída!");
    carregarVendas();
  } else {
    alert("Erro ao excluir venda.");
  }
}
function editarVenda(id) {
  localStorage.setItem("venda_editar", id);
  window.location.href = "venda_funcionario_editar.html";
}


async function carregarSelectsVendaFuncionario() {
  const cliSel = document.getElementById("cod_cli");
  if (!cliSel) return;
  try {
    const r = await fetch(`${BASE_URL}/clientes`);
    const clientes = r.ok ? await r.json() : [];
    cliSel.innerHTML = clientes.map(c => `<option value="${c.cod_cli}">${c.cod_cli} - ${c.nome_cli}</option>`).join("");
  } catch {
    cliSel.innerHTML = `<option value="">Erro ao carregar clientes</option>`;
  }
}


async function carregarItensVenda() {
  const [produtos, servicos, pacotes] = await Promise.all([
    fetch(`${BASE_URL}/produtos`).then(r => r.json()).catch(()=>[]),
    fetch(`${BASE_URL}/servicos`).then(r => r.json()).catch(()=>[]),
    fetch(`${BASE_URL}/pacotes`).then(r => r.json()).catch(()=>[]),
  ]);

  const produtosDiv = document.getElementById("listaProdutos");
  const servicosDiv = document.getElementById("listaServicos");
  const pacotesDiv  = document.getElementById("listaPacotes");

  if (produtosDiv) produtosDiv.innerHTML = produtos.map(p => `
    <div class="d-flex align-items-center gap-2 mb-2">
      <span class="flex-grow-1">${p.cod_produto} - ${p.nome_produto}</span>
      <input type="number" min="0" id="produto_${p.cod_produto}" placeholder="Qtd" class="form-control" style="width:100px">
    </div>`).join("");
  if (servicosDiv) servicosDiv.innerHTML = servicos.map(s => `
    <div class="d-flex align-items-center gap-2 mb-2">
      <span class="flex-grow-1">${s.cod_servico} - ${s.nome_servico}</span>
      <input type="number" min="0" id="servico_${s.cod_servico}" placeholder="Qtd" class="form-control" style="width:100px">
    </div>`).join("");
  if (pacotesDiv) pacotesDiv.innerHTML = pacotes.map(p => `
    <div class="d-flex align-items-center gap-2 mb-2">
      <span class="flex-grow-1">${p.cod_pacote} - ${p.nome_pacote}</span>
      <input type="number" min="0" id="pacote_${p.cod_pacote}" placeholder="Qtd" class="form-control" style="width:100px">
    </div>`).join("");
}

function coletarItens(tipo) {
  const inputs = document.querySelectorAll(`[id^="${tipo}_"]`);
  return Array.from(inputs)
    .filter(i => Number(i.value) > 0)
    .map(i => ({
      [`cod_${tipo}`]: Number(i.id.split("_")[1]),
      [`quant_vendido_${tipo}`]: Number(i.value)
    }));
}


async function initCadastrarVenda() {
  const form = document.getElementById("formCadastrarVenda");
  if (!form) return;

  await carregarSelectsVendaFuncionario();
  await carregarItensVenda();

  const user = getAuth();
  const id_usuario = user?.ID_usuario || user?.id_usuario;
  const nome_usuario = user?.nome_usuario || "Usuário";
  const cod_f = await buscarFuncionarioPorUsuario(id_usuario);

  const funSel = document.getElementById("cod_f");
  const usuSel = document.getElementById("id_usuario");

  if (funSel) {
    if (cod_f) {
      funSel.innerHTML = `<option value="${cod_f}" selected>${cod_f} - ${nome_usuario}</option>`;
      funSel.disabled = true;
    } else {
      funSel.innerHTML = `<option value="">Funcionário não encontrado</option>`;
      funSel.disabled = true;
    }
  }
  if (usuSel) {
    usuSel.innerHTML = `<option value="${id_usuario}" selected>${nome_usuario}</option>`;
    usuSel.disabled = true;
  }

  const dataVenda = document.getElementById("data_venda");
  if (dataVenda && !dataVenda.value) {
    dataVenda.value = new Date().toISOString().slice(0, 10); 
  }

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payload = {
      cod_cli: document.getElementById("cod_cli").value,
      cod_f: cod_f ?? null,
      id_usuario: id_usuario ?? null,
      valor_total: document.getElementById("valor_total").value,
      data_venda: dataVenda.value,
      produtos: coletarItens("produto"),
      servicos: coletarItens("servico"),
      pacotes: coletarItens("pacote"),
    };

    const r = await fetch(`${BASE_URL}/vendasFuncionario`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (r.ok) {
      alert("Venda cadastrada com sucesso!");
      window.location.href = "vendas_funcionario.html";
    } else {
      console.error("Erro cadastrar venda:", await r.text());
      alert("Erro ao cadastrar venda.");
    }
  });
}
document.addEventListener("DOMContentLoaded", initCadastrarVenda);


async function carregarVendaEdicao() {
  const form = document.getElementById("formEditarVenda");
  if (!form) return;

  const cod = localStorage.getItem("venda_editar");
  if (!cod) return;

  
  await carregarSelectsVendaFuncionario();
  await carregarItensVenda();

  
  const r = await fetch(`${BASE_URL}/vendasFuncionario/${cod}/completo`);
  const v = await r.json();

  
  document.getElementById("cod_vendas").value = v.cod_vendas;
  document.getElementById("cod_cli").value = String(v.cod_cli);
  document.getElementById("valor_total").value = v.valor_total;
  document.getElementById("data_venda").value = v.data_venda ? new Date(v.data_venda).toISOString().slice(0,10) : "";

  
  const user = getAuth();
  const id_usuario = user?.ID_usuario || user?.id_usuario;
  const nome_usuario = user?.nome_usuario || "Usuário";
  const cod_f = await buscarFuncionarioPorUsuario(id_usuario);

  const funSel = document.getElementById("cod_f");
  const usuSel = document.getElementById("id_usuario");

  if (funSel) {
    if (cod_f) {
      funSel.innerHTML = `<option value="${cod_f}" selected>${cod_f} - ${nome_usuario}</option>`;
      funSel.disabled = true;
    } else {
      funSel.innerHTML = `<option value="">Funcionário não encontrado</option>`;
      funSel.disabled = true;
    }
  }
  if (usuSel) {
    usuSel.innerHTML = `<option value="${id_usuario}" selected>${nome_usuario}</option>`;
    usuSel.disabled = true;
  }

  
  v.produtos?.forEach(p => {
    const input = document.getElementById(`produto_${p.cod_produto}`);
    if (input) input.value = p.quant_vendido_produto;
  });
  v.servicos?.forEach(s => {
    const input = document.getElementById(`servico_${s.cod_servico}`);
    if (input) input.value = s.quant_vendido_servico;
  });
  v.pacotes?.forEach(p => {
    const input = document.getElementById(`pacote_${p.cod_pacote}`);
    if (input) input.value = p.quant_vendido_pacote;
  });
}
document.addEventListener("DOMContentLoaded", carregarVendaEdicao);

async function initEditarVenda() {
  const form = document.getElementById("formEditarVenda");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const cod = document.getElementById("cod_vendas").value;
    const user = getAuth();
    const id_usuario = user?.ID_usuario || user?.id_usuario;
    const cod_f = await buscarFuncionarioPorUsuario(id_usuario);

    const payload = {
      cod_cli: document.getElementById("cod_cli").value,
      cod_f: cod_f ?? null,
      id_usuario: id_usuario ?? null,
      valor_total: document.getElementById("valor_total").value,
      data_venda: document.getElementById("data_venda").value,
      produtos: coletarItens("produto"),
      servicos: coletarItens("servico"),
      pacotes: coletarItens("pacote")
    };

    const r = await fetch(`${BASE_URL}/vendasFuncionario/${cod}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (r.ok) {
      alert("Venda atualizada com sucesso!");
      window.location.href = "vendas_funcionario.html";
    } else {
      console.error("Erro atualizar venda:", await r.text());
      alert("Erro ao atualizar venda.");
    }
  });
}
document.addEventListener("DOMContentLoaded", initEditarVenda);
