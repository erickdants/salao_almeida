
try {
  const user = requireAuth();
  document.getElementById("userName").innerText = user.nome_usuario || user.nome || user.ID_usuario || "Usuário";
} catch (err) {
}

document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("aldemia_user");
  window.location.href = "index.html";
});


document.getElementById("logoutBtn").addEventListener("click", () => {
    if (confirm("Deseja sair da conta?")) {
        localStorage.clear();
        window.location.href = "index.html";
    }
});