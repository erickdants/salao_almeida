const BASE_URL = "http://localhost:3000";


async function carregarPacotes() {
  const tbody = document.querySelector("#tabelaPacotes tbody");
  if (!tbody) return;

  const res = await fetch(`${BASE_URL}/pacotes?todos=true`);
  const pacotes = await res.json();

  tbody.innerHTML = "";

  pacotes.forEach(p => {
    tbody.innerHTML += `
      <tr>
        <td>${p.cod_pacote}</td>
        <td>${p.nome_pacote}</td>
        <td>${p.descricao ?? ""}</td>
        <td>${p.estoque_pacote}</td>
        <td>
          ${p.ativo
            ? `<span class="badge bg-success">Ativo</span>`
            : `<span class="badge bg-secondary">Inativo</span>`}
        </td>
        <td>
          <button class="btn btn-sm btn-primary me-1"
            onclick="editarPacote(${p.cod_pacote})">
            Editar
          </button>

          <button class="btn btn-sm btn-secondary me-1"
            onclick="verAgendasPacote(${p.cod_pacote}, '${p.nome_pacote}')">
            Ver Agendas
          </button>

          ${p.ativo
            ? `<button class="btn btn-sm btn-danger"
                onclick="desativarPacote(${p.cod_pacote})">
                Desativar
              </button>`
            : `<button class="btn btn-sm btn-success"
                onclick="reativarPacote(${p.cod_pacote})">
                Reativar
              </button>`}
        </td>
      </tr>
    `;
  });
}


function editarPacote(cod) {
  localStorage.setItem("pacote_editar", cod);
  window.location.href = "pacote_editar.html";
}

async function desativarPacote(cod) {
  if (!confirm("Desativar pacote?")) return;
  await fetch(`${BASE_URL}/pacotes/${cod}`, { method: "DELETE" });
  carregarPacotes();
}

async function reativarPacote(cod) {
  if (!confirm("Reativar pacote?")) return;
  await fetch(`${BASE_URL}/pacotes/${cod}/reativar`, { method: "PUT" });
  carregarPacotes();
}


async function verAgendasPacote(cod, nome) {
  document.getElementById("tituloAgendas").textContent = `Pacote: ${nome}`;
  document.getElementById("panelAgendas").style.display = "block";

  const res = await fetch(`${BASE_URL}/pacotes/${cod}/utilizacoes`);
  const dados = await res.json();

  const tbody = document.getElementById("tbodyPacotes");

  tbody.innerHTML = dados.length
    ? dados.map(d => `
        <tr>
          <td>${d.cod_agenda}</td>
          <td>${d.quant_pacote ?? d.quantidade ?? 1}</td>
        </tr>
      `).join("")
    : `
      <tr>
        <td colspan="2" class="text-center">
          Nenhuma agenda encontrada
        </td>
      </tr>`;
}

function fecharAgendas() {
  document.getElementById("panelAgendas").style.display = "none";
}

document.addEventListener("DOMContentLoaded", carregarPacotes);



const formCadastrar = document.getElementById("formCadastrarPacote");
if (formCadastrar) {
  formCadastrar.addEventListener("submit", async e => {
    e.preventDefault();

    await fetch(`${BASE_URL}/pacotes`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome_pacote: nome_pacote.value,
        descricao: descricao.value,
        estoque_pacote: estoque_pacote.value
      })
    });

    alert("Pacote cadastrado!");
    window.location.href = "pacotes.html";
  });
}


const formEditar = document.getElementById("formEditarPacote");
if (formEditar) {
  const cod = localStorage.getItem("pacote_editar");

  fetch(`${BASE_URL}/pacotes/${cod}`)
    .then(r => r.json())
    .then(p => {
      nome_pacote.value = p.nome_pacote;
      descricao.value = p.descricao ?? "";
      estoque_pacote.value = p.estoque_pacote;
    });

  formEditar.addEventListener("submit", async e => {
    e.preventDefault();

    await fetch(`${BASE_URL}/pacotes/${cod}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome_pacote: nome_pacote.value,
        descricao: descricao.value,
        estoque_pacote: estoque_pacote.value
      })
    });

    alert("Pacote atualizado!");
    window.location.href = "pacotes.html";
  });
}

document.addEventListener("DOMContentLoaded", carregarPacotes);
