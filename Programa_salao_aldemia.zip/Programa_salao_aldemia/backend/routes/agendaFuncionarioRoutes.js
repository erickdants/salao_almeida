import express from "express"; 
import {
  cadastrarAgenda,
  buscarAgendaCompleta,
  editarAgenda,
  excluirAgenda,
  listarAgendasFuncionario
} from "../controllers/agendaFuncionarioController.js";

const router = express.Router();

router.get("/funcionario/:cod_f", listarAgendasFuncionario);
router.post("/", cadastrarAgenda);
router.get("/:cod/completo", buscarAgendaCompleta);
router.put("/:cod", editarAgenda);
router.delete("/:cod", excluirAgenda);

export default router;
