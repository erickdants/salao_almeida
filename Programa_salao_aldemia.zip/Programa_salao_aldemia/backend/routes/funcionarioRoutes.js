import express from "express";
import {
  listarFuncionarios,
  criarFuncionario,
  obterFuncionarioPorId,
  listarAgendaDoFuncionario,
  registrarAtendimento
} from "../controllers/funcionarioController.js";

const router = express.Router();

router.get("/", listarFuncionarios);
router.post("/", criarFuncionario);
router.get("/:id", obterFuncionarioPorId);

router.get("/:id/agenda", listarAgendaDoFuncionario);

router.post("/:id/atendimentos", registrarAtendimento);

export default router;
