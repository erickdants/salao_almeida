// clientes.js
try {
  requireAuth();
} catch (err) {}

const form = document.getElementById("clienteForm");
const tbody = document.getElementById("clientesTbody");
const inputId = document.getElementById("clienteId");
const inNome = document.getElementById("nome_cli");
const inIdade = document.getElementById("idade_cli");
const inCidade = document.getElementById("cidade_cli");

async function listar() {
  try {
    const res = await fetch(`${BASE_URL}/clientes`);
    const data = await handleResponse(res);
    tbody.innerHTML = "";
    data.forEach(c => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${c.cod_cli ?? c.Cod_cli ?? ""}</td>
        <td>${c.nome_cli ?? c.nome_cli ?? ""}</td>
        <td>${c.idade_cli ?? c.idade_cli ?? ""}</td>
        <td>${c.cidade_cli ?? c.cidade_cli ?? ""}</td>
        <td>
          <button class="btn btn-sm btn-primary me-1" data-id="${c.cod_cli ?? c.Cod_cli ?? ""}" data-action="edit">Editar</button>
          <button class="btn btn-sm btn-danger" data-id="${c.cod_cli ?? c.Cod_cli ?? ""}" data-action="del">Excluir</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
    // bind buttons
    tbody.querySelectorAll("button").forEach(b => {
      b.addEventListener("click", onRowAction);
    });
  } catch (err) {
    console.error(err);
    showToast("Erro ao carregar clientes");
  }
}

async function onRowAction(e) {
  const id = e.currentTarget.dataset.id;
  const action = e.currentTarget.dataset.action;
  if (action === "edit") {
    const row = e.currentTarget.closest("tr");
    inputId.value = id;
    inNome.value = row.cells[1].innerText;
    inIdade.value = row.cells[2].innerText;
    inCidade.value = row.cells[3].innerText;
  } else if (action === "del") {
    if (!confirm("Confirma exclusão?")) return;
    try {
      const res = await fetch(`${BASE_URL}/clientes/${encodeURIComponent(id)}`, { method: "DELETE" });
      await handleResponse(res);
      showToast("Cliente excluído");
      listar();
    } catch (err) {
      console.error(err);
      showToast("Erro ao excluir");
    }
  }
}

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = {
    nome_cli: inNome.value.trim(),
    idade_cli: inIdade.value ? Number(inIdade.value) : null,
    cidade_cli: inCidade.value.trim()
  };
  const id = inputId.value;
  try {
    if (id) {
      const res = await fetch(`${BASE_URL}/clientes/${encodeURIComponent(id)}`, {
        method: "PUT",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(payload)
      });
      await handleResponse(res);
      showToast("Cliente atualizado");
      inputId.value = "";
    } else {
      const res = await fetch(`${BASE_URL}/clientes`, {
        method: "POST",
        headers: {"Content-Type":"application/json"},
        body: JSON.stringify(payload)
      });
      await handleResponse(res);
      showToast("Cliente criado");
    }
    form.reset();
    listar();
  } catch (err) {
    console.error(err);
    showToast(err.error || err.mensagem || "Erro salvando cliente");
  }
});

document.getElementById("backDash").addEventListener("click", () => window.location.href = "dashboard.html");

listar();
