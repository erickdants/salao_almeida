
import pool from "../db.js";

async function gerarIdUsuario() {
  const res = await pool.query(`
    SELECT id_usuario 
    FROM Usuario 
    WHERE id_usuario LIKE '1%%%%%%%' 
    ORDER BY id_usuario DESC 
    LIMIT 1
  `);

  if (res.rows.length === 0) return "10000001";

  const ultimo = parseInt(res.rows[0].id_usuario, 10);
  const novo = ultimo + 1;

  return String(novo).padStart(8, "0");
}


export const listarFuncionarios = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT f.cod_f, f.id_usuario, u.nome_usuario,
             f.status, f.ch
      FROM Funcionario f
      INNER JOIN Usuario u ON u.id_usuario = f.id_usuario
      ORDER BY f.cod_f DESC
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar funcionários:", err);
    res.status(500).send("Erro ao listar funcionários");
  }
};


export const cadastrarFuncionario = async (req, res) => {
  const { funcionario, contatos, especializacoes } = req.body;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const nome_usuario = funcionario.nome_usuario;
    const senha_usuario = funcionario.senha_usuario;
    const status = funcionario.status ?? null;
    const ch = funcionario.ch ?? null;

    if (!ch) throw new Error("CH não pode ser nulo — o front não enviou CH");

 
    const id_usuario = await gerarIdUsuario();

    
    await client.query(
      `INSERT INTO Usuario (nome_usuario, id_usuario, senha_usuario)
       VALUES ($1, $2, $3)`,
      [nome_usuario, id_usuario, senha_usuario]
    );


    const funcRes = await client.query(
      `INSERT INTO Funcionario (id_usuario, status, ch)
       VALUES ($1, $2, $3)
       RETURNING cod_f`,
      [id_usuario, status, ch]
    );

    const cod_f = funcRes.rows[0].cod_f;

   
    if (Array.isArray(contatos)) {
      for (const c of contatos) {
        await client.query(
          `INSERT INTO Funcionario_contato (cod_f, contato)
           VALUES ($1, $2)`,
          [cod_f, c]
        );
      }
    }

   
    if (Array.isArray(especializacoes)) {
      for (const e of especializacoes) {
        await client.query(
          `INSERT INTO Funcionario_especializacao (cod_f, especializacao)
           VALUES ($1, $2)`,
          [cod_f, e]
        );
      }
    }

    await client.query("COMMIT");
    res.status(201).json({ message: "Funcionário cadastrado!", cod_f, id_usuario });

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao cadastrar funcionário:", err);
    res.status(500).send("Erro ao cadastrar funcionário");
  } finally {
    client.release();
  }
};

export const buscarFuncionarioCompleto = async (req, res) => {
  const { cod_f } = req.params;

  try {
    const funcionario = await pool.query(`
      SELECT f.cod_f, f.id_usuario, u.nome_usuario, u.senha_usuario,
             f.status, f.ch
      FROM Funcionario f
      INNER JOIN Usuario u ON u.id_usuario = f.id_usuario
      WHERE f.cod_f = $1
    `, [cod_f]);

    if (!funcionario.rows.length) {
      return res.status(404).send("Funcionário não encontrado");
    }

    const contatos = await pool.query(`
      SELECT contato FROM Funcionario_contato WHERE cod_f = $1
    `, [cod_f]);

    const especializacoes = await pool.query(`
      SELECT especializacao FROM Funcionario_especializacao WHERE cod_f = $1
    `, [cod_f]);

    res.json({
      funcionario: funcionario.rows[0],
      contatos: contatos.rows.map(r => r.contato),
      especializacoes: especializacoes.rows.map(r => r.especializacao),
    });

  } catch (err) {
    console.error("Erro buscar func. completo:", err);
    res.status(500).send("Erro ao buscar funcionário");
  }
};

export const editarFuncionario = async (req, res) => {
  const { cod_f } = req.params;
  const { funcionario, contatos, especializacoes } = req.body;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    await client.query(
      `UPDATE Usuario 
       SET nome_usuario=$1, senha_usuario=$2
       WHERE id_usuario=$3`,
      [
        funcionario.nome_usuario,
        funcionario.senha_usuario,
        funcionario.id_usuario
      ]
    );

    await client.query(
      `UPDATE Funcionario
       SET status=$1, ch=$2
       WHERE cod_f=$3`,
      [
        funcionario.status,
        funcionario.ch,
        cod_f
      ]
    );

    await client.query(`DELETE FROM Funcionario_contato WHERE cod_f=$1`, [cod_f]);
    if (Array.isArray(contatos)) {
      for (const c of contatos) {
        await client.query(
          `INSERT INTO Funcionario_contato (cod_f, contato) VALUES ($1,$2)`,
          [cod_f, c]
        );
      }
    }

    await client.query(`DELETE FROM Funcionario_especializacao WHERE cod_f=$1`, [cod_f]);
    if (Array.isArray(especializacoes)) {
      for (const e of especializacoes) {
        await client.query(
          `INSERT INTO Funcionario_especializacao (cod_f, especializacao) VALUES ($1,$2)`,
          [cod_f, e]
        );
      }
    }

    await client.query("COMMIT");
    res.send("Funcionário atualizado!");

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao editar funcionário:", err);
    res.status(500).send("Erro ao editar funcionário");
  } finally {
    client.release();
  }
};

export const excluirFuncionario = async (req, res) => {
  const { cod_f } = req.params;
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    await client.query(`DELETE FROM Funcionario_contato WHERE cod_f=$1`, [cod_f]);
    await client.query(`DELETE FROM Funcionario_especializacao WHERE cod_f=$1`, [cod_f]);

    const r = await client.query(`SELECT id_usuario FROM Funcionario WHERE cod_f=$1`, [cod_f]);
    if (!r.rows.length) {
      await client.query("ROLLBACK");
      return res.status(404).send("Funcionário não encontrado");
    }

    const id_usuario = r.rows[0].id_usuario;

    await client.query(`DELETE FROM Funcionario WHERE cod_f=$1`, [cod_f]);
    await client.query(`DELETE FROM Usuario WHERE id_usuario=$1`, [id_usuario]);

    await client.query("COMMIT");
    res.send("Funcionário excluído!");

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro excluir funcionário:", err);
    res.status(500).send("Erro ao excluir funcionário");
  } finally {
    client.release();
  }
};
