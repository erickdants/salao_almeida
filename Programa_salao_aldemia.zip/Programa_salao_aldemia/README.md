Banco de Dados:

CREATE TABLE Usuario(
	nome_usuario varchar(100) NOT NULL,
	ID_usuario varchar(8) NOT NULL,
	senha_usuario varchar(20) NOT NULL,
	CONSTRAINT chave_usuario PRIMARY KEY(ID_usuario)
);
CREATE TABLE ADM(
	ID_usuario varchar(20) NOT NULL,
	nivel_permissao varchar(2) NOT NULL,
	Cod_ADM int NOT NULL,
	CONSTRAINT chave_ADM PRIMARY KEY(Cod_ADM, ID_usuario),
	CONSTRAINT chave_for_ADM FOREIGN KEY(ID_usuario) REFERENCES Usuario
);
CREATE TABLE Financas(
	Data_financas date NOT NULL,
	lucro numeric(20,2),
	despesas numeric(20,2),
	CONSTRAINT chave_financas PRIMARY KEY(Data_financas)
);
CREATE TABLE Cliente(
	Cod_cli int NOT NULL,
	nome_cli varchar(100),
	idade_cli int,
	rua_cli varchar(50),
	bairro_cli varchar(50),
	cidade_cli varchar(50),
	estado_cli varchar(50),
	CONSTRAINT chave_cli PRIMARY KEY(Cod_cli)
);
CREATE TABLE Anamnese_ficha(
	Cod_cli int NOT NULL,
	Cont_af serial,
	queixa_pincipal varchar(50),
	alteracao_acomete_corpo bool,
	alteracao_acomete_corpo_afirmativo varchar(200),
	tempo_alteracao int,
	problema_esta varchar(50),
	cabelo_ficou varchar(50),
	alteracao_cabelo varchar(150),
	teve_outras_crises bool,
	quando_teve_outras_crises varchar(50),
	relatorio varchar(150),
	CONSTRAINT chave_anamnese_ficha_af PRIMARY KEY(Cod_cli,Cont_af),
	CONSTRAINT chave_for_anamnese_ficha_af FOREIGN KEY(Cod_cli) REFERENCES Cliente
);
CREATE TABLE Anamnese_historico_pessoal(
	Cod_cli int NOT NULL,
	Cont_ahp serial,
	alguma_doenca bool,
	qual_doenca varchar(50),
	frequencia_modo_lavagem_cabelo varchar(200),
	cosmeticos_utilizados varchar(200),
	alergia_cosmetico_medicamento varchar(150),
	qual_alergia_cosmetico_medicamento varchar(150),
	parente_com_calvicie bool,
	CONSTRAINT chave_anamnese_ficha_ahp PRIMARY KEY(Cod_cli,Cont_ahp),
	CONSTRAINT chave_for_anamnese_ficha_ahp FOREIGN KEY(Cod_cli) REFERENCES Cliente
);
CREATE TABLE Anamnese_cuidados_cabelo(
	Cod_cli int NOT NULL,
	Cont_acc serial,
	faz_quimica bool,
	qual_quimica varchar(150),
	frequencia_quimica varchar(100),
	utiliza_acessorio varchar(150),
	CONSTRAINT chave_anamnese_ficha_acc PRIMARY KEY(Cod_cli,Cont_acc),
	CONSTRAINT chave_for_anamnese_ficha_acc FOREIGN KEY(Cod_cli) REFERENCES Cliente
);
CREATE TABLE Anamnese_exame_fisico(
	Cod_cli int NOT NULL,
	Cont serial,
	Couro_capiludo_apresenta varchar(150),
	Presenca_couro_capiludo varchar(150),
	Comprimento_cabelo_igual bool,
	Cabelo_possui varchar(150),
	Pontas_cabelo bool,
	Fios_encontrados varchar(150),
	Cor_cabelo varchar(150),
	Natural_cabelo bool,
	Tipo_cabelo varchar(150),
	Texturização_cabelo varchar(150),
	Curvatura_cabelo varchar(150),
	Espessura_cabelo varchar(150),
	Densidade_cabelo varchar(150),
	Porosidade_cabelo varchar(150),
	Elasticidade_cabelo varchar(150),
	Complicações_cabelo varchar(150),
	Observacao_complementar varchar(150),
	CONSTRAINT chave_anamnese_ficha PRIMARY KEY(Cod_cli,Cont),
	CONSTRAINT chave_for_anamnese_ficha FOREIGN KEY(Cod_cli) REFERENCES Cliente
);
CREATE TABLE Agenda(
	Cod_agenda int NOT NULL,
	Cod_cli int NOT NULL,
	Data_agenda date,
	CONSTRAINT chave_agenda PRIMARY KEY(Cod_agenda),
	CONSTRAINT chave_for_agenda FOREIGN KEY(Cod_cli) REFERENCES Cliente
);
CREATE TABLE Funcionario(
	ID_usuario varchar(8) NOT NULL,
	Cod_f int NOT NULL,
	Status varchar(15),
	CH int NOT NULL,
	Cod_agenda int,
	CONSTRAINT chave_funcionario PRIMARY KEY(ID_usuario, Cod_f),
	CONSTRAINT chave_for_funcionario1 FOREIGN KEY(ID_usuario) REFERENCES Usuario
);
CREATE TABLE Funcionario_contato(
	Cod_f int NOT NULL,
	Contato varchar(50),
	CONSTRAINT chave_funci_con PRIMARY KEY(Cod_f,Contato),
	CONSTRAINT chave_for_funci_con FOREIGN KEY(Cod_f) REFERENCES Funcionario
);
CREATE TABLE Funcionario_especializacao(
	Cod_f int NOT NULL,
	Especializacao varchar(50),
	CONSTRAINT chave_funci_con PRIMARY KEY(Cod_f,Especializacao),
	CONSTRAINT chave_for_funci_con FOREIGN KEY(Cod_f) REFERENCES Funcionario
);
CREATE TABLE Funci_cliente(
	Cod_cli int NOT NULL,
	Cod_f int NOT NULL,
	Data_acontecimento date,
	CONSTRAINT chave_funci_cliente PRIMARY KEY(Cod_cli,Cod_f),
	CONSTRAINT chave_for_funci FOREIGN KEY(Cod_f) REFERENCES Funcionario,
	CONSTRAINT chave_for_cli FOREIGN KEY(Cod_cli) REFERENCES Cliente
);
CREATE TABLE Produto(
	Cod_produto int NOT NULL,
	Nome_produto varchar(50),
	CONSTRAINT chave_produto PRIMARY KEY(Cod_produto)
);
CREATE TABLE Pacote(
	Cod_pacote int NOT NULL,
	Nome_pacote varchar(50),
	CONSTRAINT chave_pacote PRIMARY KEY(Cod_pacote)
);
CREATE TABLE Servico(
	Cod_servico int NOT NULL,
	Nome_servico varchar(50),
	CONSTRAINT chave_servico PRIMARY KEY(Cod_servico)
);
CREATE TABLE Agenda_utilizara_produto(
	Cod_agenda int NOT NULL,
	Cod_produto int NOT NULL,
	quant_produto int,
	CONSTRAINT chave_agenda_utilizara_produto PRIMARY KEY(Cod_agenda,Cod_produto),
	CONSTRAINT chave_for_agenda FOREIGN KEY(Cod_agenda) REFERENCES Agenda,
	CONSTRAINT chave_for_produto FOREIGN KEY(Cod_produto) REFERENCES Produto
);
CREATE TABLE Agenda_utilizara_pacote(
	Cod_agenda int NOT NULL,
	Cod_pacote int NOT NULL,
	quant_pacote int,
	CONSTRAINT chave_agenda_utilizara_pacote PRIMARY KEY(Cod_agenda,Cod_pacote),
	CONSTRAINT chave_for_agenda FOREIGN KEY(Cod_agenda) REFERENCES Agenda,
	CONSTRAINT chave_for_pacote FOREIGN KEY(Cod_pacote) REFERENCES Pacote
);
CREATE TABLE Agenda_utilizara_servico(
	Cod_agenda int NOT NULL,
	Cod_servico int NOT NULL,
	quant_servico int,
	CONSTRAINT chave_agenda_utilizara_servico PRIMARY KEY(Cod_agenda,Cod_servico),
	CONSTRAINT chave_for_agenda FOREIGN KEY(Cod_agenda) REFERENCES Agenda,
	CONSTRAINT chave_for_servico FOREIGN KEY(Cod_servico) REFERENCES Produto
);
CREATE TABLE Vendas(
	Cod_vendas int NOT NULL,
	Valor_total int,
	Cod_f int NOT NULL,
	Cod_cli int NOT NULL,
	CONSTRAINT chave_vendas PRIMARY KEY(Cod_vendas),
	CONSTRAINT chave_for_vendas1 FOREIGN KEY(Cod_f) REFERENCES Funcionario,
	CONSTRAINT chave_for_vendas2 FOREIGN KEY(Cod_cli) REFERENCES Cliente
);
CREATE TABLE Produto_vendido(
	Cod_vendas int NOT NULL,
	Cod_produto int NOT NULL,
	quant_vendido_produto int,
	CONSTRAINT chave_vendido_produto PRIMARY KEY(Cod_produto,Cod_vendas),
	CONSTRAINT chave_for_venda FOREIGN KEY(Cod_vendas) REFERENCES vendas,
	CONSTRAINT chvae_for_produto FOREIGN KEY(Cod_produto) REFERENCES Produto
);
CREATE TABLE Pacote_vendido(
	Cod_vendas int NOT NULL,
	Cod_pacote int NOT NULL,
	quant_vendido_pacote int,
	CONSTRAINT chave_vendido_pacote PRIMARY KEY(Cod_pacote,Cod_vendas),
	CONSTRAINT chave_for_venda FOREIGN KEY(Cod_vendas) REFERENCES vendas,
	CONSTRAINT chvae_for_pacote FOREIGN KEY(Cod_pacote) REFERENCES Produto
);
CREATE TABLE Servico_vendido(
	Cod_vendas int NOT NULL,
	Cod_servico int NOT NULL,
	quant_vendido_servico int,
	CONSTRAINT chave_vendido_servico PRIMARY KEY(Cod_servico,Cod_vendas),
	CONSTRAINT chave_for_venda FOREIGN KEY(Cod_vendas) REFERENCES vendas,
	CONSTRAINT chvae_for_servico FOREIGN KEY(Cod_servico) REFERENCES Produto
)

