import express from "express";
import {
  listarProdutos,
  cadastrarProduto,
  atualizarProduto,
  excluirProduto
} from "../controllers/produtoController.js";

const router = express.Router();

router.get("/", listarProdutos);
router.post("/", cadastrarProduto);
router.put("/:id", atualizarProduto);
router.delete("/:id", excluirProduto);

export default router;
