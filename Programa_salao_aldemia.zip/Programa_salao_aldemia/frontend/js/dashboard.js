// dashboard.js
try {
  const user = requireAuth();
  document.getElementById("userName").innerText = user.nome_usuario || user.nome || user.ID_usuario || "Usuário";
} catch (err) {
  // requireAuth redireciona
}

document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("aldemia_user");
  window.location.href = "index.html";
});
