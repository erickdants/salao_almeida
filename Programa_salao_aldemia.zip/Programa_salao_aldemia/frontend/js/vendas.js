
const BASE_URL = "http://localhost:3000";


async function carregarVendas() {
  const tabela = document.querySelector("#tabelaVendas tbody");
  if (!tabela) return;

  try {
    const res = await fetch(`${BASE_URL}/vendas`);
    const vendas = await res.json();
    tabela.innerHTML = "";

    vendas.forEach(v => {
      tabela.innerHTML += `
        <tr>
          <td>${v.cod_vendas}</td>
          <td>${v.nome_cli}</td>
          <td>${v.nome_funcionario ?? "—"}</td>
          <td>${v.nome_usuario_venda ?? "—"}</td> <!-- NOVA COLUNA -->
          <td>R$ ${parseFloat(v.valor_total).toFixed(2)}</td>
          <td>${v.data_venda ? new Date(v.data_venda).toLocaleDateString("pt-BR") : "—"}</td>
          <td>
            <button class="btn btn-sm btn-info" onclick="verDetalhes(${v.cod_vendas})">Detalhes</button>
            <button class="btn btn-sm btn-primary" onclick="editarVenda(${v.cod_vendas})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="excluirVenda(${v.cod_vendas})">Excluir</button>
          </td>
        </tr>
      `;
    });
  } catch (err) {
    console.error("Erro ao listar vendas:", err);
  }
}

document.addEventListener("DOMContentLoaded", carregarVendas);

async function verDetalhes(id) {
  const res = await fetch(`${BASE_URL}/vendas/${id}/completo`);
  const v = await res.json();

  const div = document.getElementById("detalhesConteudo");
  div.innerHTML = `
    <p><b>Código:</b> ${v.cod_vendas}</p>
    <p><b>Cliente:</b> ${v.cod_cli}</p>
    <p><b>Funcionário:</b> ${v.cod_f ?? "—"}</p>
    <p><b>Usuário:</b> ${v.id_usuario}</p>
    <p><b>Valor Total:</b> R$ ${parseFloat(v.valor_total).toFixed(2)}</p>
    <p><b>Data da Venda:</b> ${v.data_venda ? new Date(v.data_venda).toLocaleDateString("pt-BR") : "—"}</p>

    <h5 class="mt-3">Produtos</h5>
    ${v.produtos?.length ? v.produtos.map(p => `<div>${p.nome_produto} — ${p.quant_vendido_produto}</div>`).join("") : "<p>Nenhum produto</p>"}

    <h5 class="mt-3">Serviços</h5>
    ${v.servicos?.length ? v.servicos.map(s => `<div>${s.nome_servico} — ${s.quant_vendido_servico}</div>`).join("") : "<p>Nenhum serviço</p>"}

    <h5 class="mt-3">Pacotes</h5>
    ${v.pacotes?.length ? v.pacotes.map(p => `<div>${p.nome_pacote} — ${p.quant_vendido_pacote}</div>`).join("") : "<p>Nenhum pacote</p>"}
  `;

  document.getElementById("detalhesVenda").style.display = "block";
}

function fecharDetalhes() {
  document.getElementById("detalhesVenda").style.display = "none";
}



function editarVenda(id) {
  localStorage.setItem("venda_editar", id);
  window.location.href = "venda_editar.html";
}


async function excluirVenda(id) {
  if (!confirm("Deseja excluir esta venda?")) return;

  try {
    const res = await fetch(`${BASE_URL}/vendas/${id}`, { method: "DELETE" });
    if (res.ok) {
      alert("Venda excluída!");
      carregarVendas();
    } else {
      const txt = await res.text();
      console.error("Erro excluir venda:", txt);
      alert("Erro ao excluir venda.");
    }
  } catch (err) {
    console.error("Erro excluir venda:", err);
  }
}

async function carregarSelectsVenda() {
  const cliSel = document.getElementById("cod_cli");
  const funSel = document.getElementById("cod_f");
  const usuSel = document.getElementById("id_usuario");

  if (!cliSel) return;

  const [clientes, funcionarios, usuarios] = await Promise.all([
    fetch(`${BASE_URL}/clientes`).then(r => r.json()),
    fetch(`${BASE_URL}/funcionarios`).then(r => r.json()),
    fetch(`${BASE_URL}/usuarios`).then(r => r.json())
  ]);

  cliSel.innerHTML = clientes.map(c => `<option value="${c.cod_cli}">${c.nome_cli}</option>`).join("");
  funSel.innerHTML = `<option value="">Nenhum</option>` +
    funcionarios.map(f => `<option value="${f.cod_f}">${f.nome_usuario}</option>`).join("");
  usuSel.innerHTML = usuarios.map(u => `<option value="${u.id_usuario}">${u.nome_usuario}</option>`).join("");
}

async function carregarItensVenda() {
  const produtos = await (await fetch(`${BASE_URL}/produtos`)).json();
  const servicos = await (await fetch(`${BASE_URL}/servicos`)).json();
  const pacotes = await (await fetch(`${BASE_URL}/pacotes`)).json();

  const produtosDiv = document.getElementById("listaProdutos");
  const servicosDiv = document.getElementById("listaServicos");
  const pacotesDiv = document.getElementById("listaPacotes");

  if (produtosDiv)
    produtosDiv.innerHTML = produtos.map(p => `
      <div class="d-flex align-items-center gap-2 mb-2">
        <span class="flex-grow-1">${p.cod_produto} - ${p.nome_produto}</span>
        <input type="number" min="0" id="produto_${p.cod_produto}" placeholder="Qtd" class="form-control" style="width:100px">
      </div>
    `).join("");

  if (servicosDiv)
    servicosDiv.innerHTML = servicos.map(s => `
      <div class="d-flex align-items-center gap-2 mb-2">
        <span class="flex-grow-1">${s.cod_servico} - ${s.nome_servico}</span>
        <input type="number" min="0" id="servico_${s.cod_servico}" placeholder="Qtd" class="form-control" style="width:100px">
      </div>
    `).join("");

  if (pacotesDiv)
    pacotesDiv.innerHTML = pacotes.map(p => `
      <div class="d-flex align-items-center gap-2 mb-2">
        <span class="flex-grow-1">${p.cod_pacote} - ${p.nome_pacote}</span>
        <input type="number" min="0" id="pacote_${p.cod_pacote}" placeholder="Qtd" class="form-control" style="width:100px">
      </div>
    `).join("");
}


function coletarItens(tipo) {
  const inputs = document.querySelectorAll(`[id^="${tipo}_"]`);
  return Array.from(inputs)
    .filter(i => Number(i.value) > 0)
    .map(i => ({
      [`cod_${tipo}`]: Number(i.id.split("_")[1]),
      [`quant_vendido_${tipo}`]: Number(i.value)
    }));
}


async function initCadastrarVenda() {
  const form = document.getElementById("formCadastrarVenda");
  if (!form) return;

  await carregarSelectsVenda();
  await carregarItensVenda();

  // define data padrão de hoje
  document.getElementById("data_venda").value = new Date().toISOString().split("T")[0];

  form.addEventListener("submit", async e => {
    e.preventDefault();

    const payload = {
      cod_cli: document.getElementById("cod_cli").value,
      cod_f: document.getElementById("cod_f").value || null,
      id_usuario: document.getElementById("id_usuario").value,
      valor_total: document.getElementById("valor_total").value,
      data_venda: document.getElementById("data_venda").value,
      produtos: coletarItens("produto"),
      servicos: coletarItens("servico"),
      pacotes: coletarItens("pacote")
    };

    try {
      const res = await fetch(`${BASE_URL}/vendas`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        alert("Venda cadastrada com sucesso!");
        window.location.href = "vendas.html";
      } else {
        const txt = await res.text();
        console.error("Erro cadastrar venda:", txt);
        alert("Erro ao cadastrar venda.");
      }
    } catch (err) {
      console.error("Erro cadastrar venda (front):", err);
    }
  });
}
initCadastrarVenda();


async function carregarVendaEdicao() {
  const cod = localStorage.getItem("venda_editar");
  const form = document.getElementById("formEditarVenda");
  if (!form || !cod) return;

  await carregarSelectsVenda();
  await carregarItensVenda();

  const res = await fetch(`${BASE_URL}/vendas/${cod}/completo`);
  const venda = await res.json();

  document.getElementById("cod_vendas").value = venda.cod_vendas;
  document.getElementById("cod_cli").value = venda.cod_cli;
  document.getElementById("cod_f").value = venda.cod_f ?? "";
  document.getElementById("id_usuario").value = venda.id_usuario ?? "";
  document.getElementById("valor_total").value = venda.valor_total;
  document.getElementById("data_venda").value = venda.data_venda ? venda.data_venda.substring(0, 10) : "";

  // preencher itens
  venda.produtos?.forEach(p => {
    const input = document.getElementById(`produto_${p.cod_produto}`);
    if (input) input.value = p.quant_vendido_produto;
  });

  venda.servicos?.forEach(s => {
    const input = document.getElementById(`servico_${s.cod_servico}`);
    if (input) input.value = s.quant_vendido_servico;
  });

  venda.pacotes?.forEach(p => {
    const input = document.getElementById(`pacote_${p.cod_pacote}`);
    if (input) input.value = p.quant_vendido_pacote;
  });
}
document.addEventListener("DOMContentLoaded", carregarVendaEdicao);


async function initEditarVenda() {
  const form = document.getElementById("formEditarVenda");
  if (!form) return;

  form.addEventListener("submit", async e => {
    e.preventDefault();

    const cod = document.getElementById("cod_vendas").value;

    const payload = {
      cod_cli: document.getElementById("cod_cli").value,
      cod_f: document.getElementById("cod_f").value || null,
      id_usuario: document.getElementById("id_usuario").value,
      valor_total: document.getElementById("valor_total").value,
      data_venda: document.getElementById("data_venda").value,
      produtos: coletarItens("produto"),
      servicos: coletarItens("servico"),
      pacotes: coletarItens("pacote")
    };

    try {
      const res = await fetch(`${BASE_URL}/vendas/${cod}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        alert("Venda atualizada com sucesso!");
        window.location.href = "vendas.html";
      } else {
        const txt = await res.text();
        console.error("Erro atualizar venda:", txt);
        alert("Erro ao atualizar venda.");
      }
    } catch (err) {
      console.error("Erro editar venda (front):", err);
    }
  });
}
initEditarVenda();
