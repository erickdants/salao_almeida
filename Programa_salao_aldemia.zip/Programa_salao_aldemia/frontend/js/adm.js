const BASE_URL = "http://localhost:3000";


document.getElementById("formVerificarADM")?.addEventListener("submit", async (e) => {
  e.preventDefault();

  const ID_usuario = document.getElementById("adm_id").value;
  const senha = document.getElementById("adm_senha").value;

  try {
    const res = await fetch(`${BASE_URL}/adm/validar`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ID_usuario, senha })
    });

    if (!res.ok) {
      alert("Credenciais inválidas!");
      return;
    }

    // Sucesso
    window.location.href = "adm_cadastrar.html";

  } catch (err) {
    console.error(err);
    alert("Erro ao validar administrador");
  }
});



document.getElementById("formCadastrarADM")?.addEventListener("submit", async (e) => {
  e.preventDefault();

  const payload = {
    nome_usuario: document.getElementById("nome_usuario").value,
    senha_usuario: document.getElementById("senha_usuario").value
  };

  try {
    const res = await fetch(`${BASE_URL}/adm`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      alert("Erro ao cadastrar ADM");
      return;
    }

    alert("Administrador criado com sucesso!");
    window.location.href = "index.html";

  } catch (err) {
    console.error(err);
    alert("Erro ao cadastrar administrador");
  }
});
