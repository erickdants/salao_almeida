import express from "express";
import {
  listarProdutos,
  cadastrarProduto,
  buscarProdutoCompleto,
  editarProduto,
  excluirProduto,
  listarUtilizacoesProduto,
  reativarProduto
} from "../controllers/produtoController.js";

const router = express.Router();

router.get("/", listarProdutos);
router.get("/:cod", buscarProdutoCompleto);
router.post("/", cadastrarProduto);
router.put("/:cod", editarProduto);
router.delete("/:cod", excluirProduto);
router.get("/:cod/utilizacoes", listarUtilizacoesProduto);
router.put("/:cod/reativar", reativarProduto);

export default router;
