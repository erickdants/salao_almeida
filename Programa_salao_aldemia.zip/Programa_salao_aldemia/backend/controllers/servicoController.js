import pool from "../db.js";

export const listarServicos = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM Servico ORDER BY id_servico ASC");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const cadastrarServico = async (req, res) => {
  const { nome_servico, preco_servico } = req.body;
  try {
    const result = await pool.query(
      "INSERT INTO Servico (nome_servico, preco_servico) VALUES ($1, $2) RETURNING *",
      [nome_servico, preco_servico]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const atualizarServico = async (req, res) => {
  const { id } = req.params;
  const { nome_servico, preco_servico } = req.body;
  try {
    const result = await pool.query(
      "UPDATE Servico SET nome_servico=$1, preco_servico=$2 WHERE id_servico=$3 RETURNING *",
      [nome_servico, preco_servico, id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const excluirServico = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM Servico WHERE id_servico=$1", [id]);
    res.json({ mensagem: "Serviço removido com sucesso!" });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};
