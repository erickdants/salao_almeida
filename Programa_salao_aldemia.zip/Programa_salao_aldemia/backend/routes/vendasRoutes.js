import express from "express";
import {
  listarVendas,
  buscarVendaCompleta,
  cadastrarVenda,
  editarVenda,
  excluirVenda
} from "../controllers/vendasController.js";

const router = express.Router();


router.get("/", listarVendas);
router.get("/:cod_vendas/completo", buscarVendaCompleta);
router.post("/", cadastrarVenda);
router.put("/:cod_vendas", editarVenda);
router.delete("/:cod_vendas", excluirVenda);

export default router;
