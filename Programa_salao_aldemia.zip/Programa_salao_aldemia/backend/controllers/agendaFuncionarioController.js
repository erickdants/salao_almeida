import pool from "../db.js";


export const listarAgendasFuncionario = async (req, res) => {
  const { cod_f } = req.params; 
  const { data } = req.query;

  try {
    let query = `
      SELECT 
        a.cod_agenda,
        a.cod_cli,
        c.nome_cli,
        a.cod_f,
        u.nome_usuario AS nome_funcionario,
        a.data_agenda,
        a.descricao
      FROM Agenda a
      INNER JOIN Cliente c      ON c.cod_cli = a.cod_cli
      LEFT JOIN Funcionario f   ON f.cod_f   = a.cod_f
      LEFT JOIN Usuario u       ON u.id_usuario = f.id_usuario
      WHERE a.cod_f = $1
    `;
    const params = [cod_f];

    if (data) {
      query += ` AND DATE(a.data_agenda) = $2`;
      params.push(data);
    }

    query += " ORDER BY a.cod_agenda DESC";

    const result = await pool.query(query, params);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar agendas do funcionário:", err);
    res.status(500).send("Erro ao listar agendas do funcionário");
  }
};


export const cadastrarAgenda = async (req, res) => {
  const { cod_cli, cod_f, data_agenda, descricao, produtos, servicos, pacotes } = req.body;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const r = await client.query(
      `INSERT INTO Agenda (cod_cli, cod_f, data_agenda, descricao)
       VALUES ($1, $2, $3, $4)
       RETURNING cod_agenda`,
      [cod_cli, cod_f || null, data_agenda, descricao]
    );
    const cod_agenda = r.rows[0].cod_agenda;

    if (Array.isArray(produtos)) {
      for (const p of produtos) {
        await client.query(
          `INSERT INTO Agenda_utilizara_produto (cod_agenda, cod_produto, quant_produto)
           VALUES ($1, $2, $3)`,
          [cod_agenda, p.cod_produto, p.quant_produto]
        );
      }
    }

    if (Array.isArray(servicos)) {
      for (const s of servicos) {
        await client.query(
          `INSERT INTO Agenda_utilizara_servico (cod_agenda, cod_servico, quant_servico)
           VALUES ($1, $2, $3)`,
          [cod_agenda, s.cod_servico, s.quant_servico]
        );
      }
    }

    if (Array.isArray(pacotes)) {
      for (const p of pacotes) {
        await client.query(
          `INSERT INTO Agenda_utilizara_pacote (cod_agenda, cod_pacote, quant_pacote)
           VALUES ($1, $2, $3)`,
          [cod_agenda, p.cod_pacote, p.quant_pacote]
        );
      }
    }

    await client.query("COMMIT");
    res.status(201).json({ message: "Agenda cadastrada!", cod_agenda });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao cadastrar agenda:", err);
    res.status(500).send("Erro ao cadastrar agenda");
  } finally {
    client.release();
  }
};


export const buscarAgendaCompleta = async (req, res) => {
  const { cod } = req.params;
  try {
    const cab = await pool.query(`
      SELECT 
        a.*, c.nome_cli, u.nome_usuario AS nome_funcionario
      FROM Agenda a
      INNER JOIN Cliente c ON c.cod_cli = a.cod_cli
      LEFT JOIN Funcionario f ON f.cod_f = a.cod_f
      LEFT JOIN Usuario u ON u.id_usuario = f.id_usuario
      WHERE a.cod_agenda = $1
    `, [cod]);

    if (!cab.rows.length) return res.status(404).send("Agenda não encontrada");

    const produtos = await pool.query(
      "SELECT cod_produto, quant_produto FROM Agenda_utilizara_produto WHERE cod_agenda=$1",
      [cod]
    );
    const servicos = await pool.query(
      "SELECT cod_servico, quant_servico FROM Agenda_utilizara_servico WHERE cod_agenda=$1",
      [cod]
    );
    const pacotes = await pool.query(
      "SELECT cod_pacote, quant_pacote FROM Agenda_utilizara_pacote WHERE cod_agenda=$1",
      [cod]
    );

    res.json({
      ...cab.rows[0],
      produtos: produtos.rows,
      servicos: servicos.rows,
      pacotes: pacotes.rows,
    });
  } catch (err) {
    console.error("Erro buscar agenda completa:", err);
    res.status(500).send("Erro ao buscar agenda");
  }
};


export const editarAgenda = async (req, res) => {
  const { cod } = req.params;
  const { cod_cli, cod_f, data_agenda, descricao, produtos, servicos, pacotes } = req.body;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    await client.query(
      `UPDATE Agenda
       SET cod_cli=$1, cod_f=$2, data_agenda=$3, descricao=$4
       WHERE cod_agenda=$5`,
      [cod_cli, cod_f || null, data_agenda, descricao, cod]
    );

    await client.query("DELETE FROM Agenda_utilizara_produto WHERE cod_agenda=$1", [cod]);
    await client.query("DELETE FROM Agenda_utilizara_servico WHERE cod_agenda=$1", [cod]);
    await client.query("DELETE FROM Agenda_utilizara_pacote WHERE cod_agenda=$1", [cod]);

    if (Array.isArray(produtos)) {
      for (const p of produtos) {
        await client.query(
          `INSERT INTO Agenda_utilizara_produto VALUES ($1, $2, $3)`,
          [cod, p.cod_produto, p.quant_produto]
        );
      }
    }

    if (Array.isArray(servicos)) {
      for (const s of servicos) {
        await client.query(
          `INSERT INTO Agenda_utilizara_servico VALUES ($1, $2, $3)`,
          [cod, s.cod_servico, s.quant_servico]
        );
      }
    }

    if (Array.isArray(pacotes)) {
      for (const p of pacotes) {
        await client.query(
          `INSERT INTO Agenda_utilizara_pacote VALUES ($1, $2, $3)`,
          [cod, p.cod_pacote, p.quant_pacote]
        );
      }
    }

    await client.query("COMMIT");
    res.send("Agenda atualizada!");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao editar agenda:", err);
    res.status(500).send("Erro ao editar agenda");
  } finally {
    client.release();
  }
};


export const excluirAgenda = async (req, res) => {
  const { cod } = req.params;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("DELETE FROM Agenda_utilizara_produto WHERE cod_agenda=$1", [cod]);
    await client.query("DELETE FROM Agenda_utilizara_servico WHERE cod_agenda=$1", [cod]);
    await client.query("DELETE FROM Agenda_utilizara_pacote WHERE cod_agenda=$1", [cod]);
    await client.query("DELETE FROM Agenda WHERE cod_agenda=$1", [cod]);
    await client.query("COMMIT");
    res.send("Agenda excluída!");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao excluir agenda:", err);
    res.status(500).send("Erro ao excluir agenda");
  } finally {
    client.release();
  }
};

