import pool from "../db.js";

export const listarVendas = async (req, res) => {
  const { cod_f } = req.params;

  try {
    const query = `
      SELECT 
        v.cod_vendas,
        v.valor_total,
        v.data_venda,
        c.nome_cli,
        f.cod_f,
        u.nome_usuario AS nome_funcionario
      FROM vendas v
      INNER JOIN cliente c ON c.cod_cli = v.cod_cli
      LEFT JOIN funcionario f ON f.cod_f = v.cod_f
      LEFT JOIN usuario u ON u.id_usuario = f.id_usuario
      WHERE v.cod_f = $1
      ORDER BY v.cod_vendas DESC
    `;
    const result = await pool.query(query, [cod_f]);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro ao listar vendas do funcionário:", err);
    res.status(500).send("Erro ao listar vendas do funcionário");
  }
};

export const cadastrarVenda = async (req, res) => {
  const { valor_total, cod_cli, cod_f, id_usuario, produtos = [], servicos = [], pacotes = [], data_venda } = req.body;

  try {
    const novaVenda = await pool.query(
      `INSERT INTO vendas (valor_total, cod_cli, cod_f, id_usuario, data_venda)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING cod_vendas`,
      [valor_total, cod_cli, cod_f, id_usuario, data_venda || new Date()]
    );

    const cod_vendas = novaVenda.rows[0].cod_vendas;

    for (const p of produtos) {
      await pool.query(
        `INSERT INTO produto_vendido (cod_vendas, cod_produto, quant_vendido_produto)
         VALUES ($1, $2, $3)`,
        [cod_vendas, p.cod_produto, p.quant_vendido_produto]
      );
    }

    for (const s of servicos) {
      await pool.query(
        `INSERT INTO servico_vendido (cod_vendas, cod_servico, quant_vendido_servico)
         VALUES ($1, $2, $3)`,
        [cod_vendas, s.cod_servico, s.quant_vendido_servico]
      );
    }

    for (const p of pacotes) {
      await pool.query(
        `INSERT INTO pacote_vendido (cod_vendas, cod_pacote, quant_vendido_pacote)
         VALUES ($1, $2, $3)`,
        [cod_vendas, p.cod_pacote, p.quant_vendido_pacote]
      );
    }

    res.status(201).json({ message: "Venda cadastrada com sucesso!" });
  } catch (err) {
    console.error("Erro ao cadastrar venda (funcionário):", err);
    res.status(500).send("Erro ao cadastrar venda");
  }
};

export const buscarVendaCompleta = async (req, res) => {
  const { cod_vendas } = req.params;

  try {
    const venda = await pool.query(`SELECT * FROM vendas WHERE cod_vendas = $1`, [cod_vendas]);
    if (venda.rows.length === 0) return res.status(404).send("Venda não encontrada");

    const produtos = await pool.query(`
      SELECT pv.*, p.nome_produto
      FROM produto_vendido pv
      INNER JOIN produto p ON p.cod_produto = pv.cod_produto
      WHERE pv.cod_vendas = $1
    `, [cod_vendas]);

    const servicos = await pool.query(`
      SELECT sv.*, s.nome_servico
      FROM servico_vendido sv
      INNER JOIN servico s ON s.cod_servico = sv.cod_servico
      WHERE sv.cod_vendas = $1
    `, [cod_vendas]);

    const pacotes = await pool.query(`
      SELECT pv.*, p.nome_pacote
      FROM pacote_vendido pv
      INNER JOIN pacote p ON p.cod_pacote = pv.cod_pacote
      WHERE pv.cod_vendas = $1
    `, [cod_vendas]);

    res.json({
      ...venda.rows[0],
      produtos: produtos.rows,
      servicos: servicos.rows,
      pacotes: pacotes.rows
    });
  } catch (err) {
    console.error("Erro ao buscar venda completa (funcionário):", err);
    res.status(500).send("Erro ao buscar venda completa");
  }
};

export const editarVenda = async (req, res) => {
  const { cod_vendas } = req.params;
  const { valor_total, cod_cli, cod_f, id_usuario, produtos = [], servicos = [], pacotes = [], data_venda } = req.body;

  try {
    await pool.query(
      `UPDATE vendas
       SET valor_total=$1, cod_cli=$2, cod_f=$3, id_usuario=$4, data_venda=$5
       WHERE cod_vendas=$6`,
      [valor_total, cod_cli, cod_f, id_usuario, data_venda || new Date(), cod_vendas]
    );

    await pool.query(`DELETE FROM produto_vendido WHERE cod_vendas=$1`, [cod_vendas]);
    await pool.query(`DELETE FROM servico_vendido WHERE cod_vendas=$1`, [cod_vendas]);
    await pool.query(`DELETE FROM pacote_vendido WHERE cod_vendas=$1`, [cod_vendas]);

    for (const p of produtos) {
      await pool.query(
        `INSERT INTO produto_vendido (cod_vendas, cod_produto, quant_vendido_produto)
         VALUES ($1, $2, $3)`,
        [cod_vendas, p.cod_produto, p.quant_vendido_produto]
      );
    }

    for (const s of servicos) {
      await pool.query(
        `INSERT INTO servico_vendido (cod_vendas, cod_servico, quant_vendido_servico)
         VALUES ($1, $2, $3)`,
        [cod_vendas, s.cod_servico, s.quant_vendido_servico]
      );
    }

    for (const p of pacotes) {
      await pool.query(
        `INSERT INTO pacote_vendido (cod_vendas, cod_pacote, quant_vendido_pacote)
         VALUES ($1, $2, $3)`,
        [cod_vendas, p.cod_pacote, p.quant_vendido_pacote]
      );
    }

    res.send("Venda atualizada com sucesso!");
  } catch (err) {
    console.error("Erro ao editar venda (funcionário):", err);
    res.status(500).send("Erro ao editar venda");
  }
};


export const excluirVenda = async (req, res) => {
  const { cod_vendas } = req.params;

  try {
    await pool.query(`DELETE FROM produto_vendido WHERE cod_vendas=$1`, [cod_vendas]);
    await pool.query(`DELETE FROM servico_vendido WHERE cod_vendas=$1`, [cod_vendas]);
    await pool.query(`DELETE FROM pacote_vendido WHERE cod_vendas=$1`, [cod_vendas]);
    await pool.query(`DELETE FROM vendas WHERE cod_vendas=$1`, [cod_vendas]);

    res.send("Venda excluída com sucesso!");
  } catch (err) {
    console.error("Erro ao excluir venda (funcionário):", err);
    res.status(500).send("Erro ao excluir venda");
  }
};
