import express from "express";
import {
  listarFinancas,
  cadastrarFinanca,
  buscarFinanca,
  editarFinanca,
  excluirFinanca
} from "../controllers/financasController.js";

const router = express.Router();

router.get("/", listarFinancas);
router.post("/", cadastrarFinanca);
router.get("/:mes/:ano", buscarFinanca);
router.put("/:mes/:ano", editarFinanca);
router.delete("/:mes/:ano", excluirFinanca);

export default router;
