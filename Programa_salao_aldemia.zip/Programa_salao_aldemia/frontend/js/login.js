document.getElementById("loginForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const ID_usuario = document.getElementById("id_usuario").value.trim();
  const senha_usuario = document.getElementById("senha").value;

  try {
    const res = await fetch(`${BASE_URL}/usuarios/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ID_usuario, senha_usuario })
    });

    const data = await handleResponse(res);
    const usuario = data.usuario;
    const tipo = data.tipo;
    localStorage.setItem("aldemia_user", JSON.stringify(usuario));
    localStorage.setItem("aldemia_tipo", tipo);

    if (tipo === "admin") {
      window.location.href = "dashboard.html";
    } else if (tipo === "funcionario") {
      window.location.href = "dashboard_funcionario.html";
    } else {
      showToast("Tipo de usuário desconhecido.");
    }

  } catch (err) {
    console.error(err);
    showToast(err.error || err.mensagem || "Falha ao autenticar");
  }
});

