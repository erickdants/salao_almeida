const BASE_URL = "http://localhost:3000";


async function carregarDespesas() {
  const tabela = document.querySelector("#tabelaDespesas tbody");
  if (!tabela) return;

  try {
    const res = await fetch(`${BASE_URL}/despesas`);
    const despesas = await res.json();

    tabela.innerHTML = "";
    despesas.forEach(d => {
      tabela.innerHTML += `
        <tr>
          <td>${d.cod_despesa}</td>
          <td>R$ ${parseFloat(d.valor).toFixed(2)}</td>
          <td>${new Date(d.dia_despesa).toLocaleDateString("pt-BR")}</td>
          <td>${d.descricao ?? ""}</td>
          <td>
            <button class="btn btn-sm btn-primary" onclick="editarDespesa(${d.cod_despesa})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="excluirDespesa(${d.cod_despesa})">Excluir</button>
          </td>
        </tr>
      `;
    });
  } catch (err) {
    console.error("Erro listar despesas:", err);
  }
}
document.addEventListener("DOMContentLoaded", carregarDespesas);


function editarDespesa(id) {
  localStorage.setItem("despesa_editar", id);
  window.location.href = "despesa_editar.html";
}


async function initCadastrarDespesa() {
  const form = document.getElementById("formCadastrarDespesa");
  if (!form) return;

  document.getElementById("dia_despesa").value = new Date().toISOString().split("T")[0];

  form.addEventListener("submit", async e => {
    e.preventDefault();

    const payload = {
      valor: parseFloat(document.getElementById("valor").value),
      dia_despesa: document.getElementById("dia_despesa").value,
      descricao: document.getElementById("descricao").value
    };

    const res = await fetch(`${BASE_URL}/despesas`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      alert("Despesa cadastrada com sucesso!");
      window.location.href = "despesas.html";
    } else {
      alert("Erro ao cadastrar despesa.");
    }
  });
}
initCadastrarDespesa();


async function carregarDespesaEdicao() {
  const id = localStorage.getItem("despesa_editar");
  const form = document.getElementById("formEditarDespesa");
  if (!form || !id) return;

  const res = await fetch(`${BASE_URL}/despesas/${id}`);
  const d = await res.json();

  document.getElementById("cod_despesa").value = d.cod_despesa;
  document.getElementById("valor").value = d.valor;
  document.getElementById("dia_despesa").value = d.dia_despesa.substring(0, 10);
  document.getElementById("descricao").value = d.descricao ?? "";
}
document.addEventListener("DOMContentLoaded", carregarDespesaEdicao);

async function initEditarDespesa() {
  const form = document.getElementById("formEditarDespesa");
  if (!form) return;

  form.addEventListener("submit", async e => {
    e.preventDefault();
    const id = document.getElementById("cod_despesa").value;

    const payload = {
      valor: parseFloat(document.getElementById("valor").value),
      dia_despesa: document.getElementById("dia_despesa").value,
      descricao: document.getElementById("descricao").value
    };

    const res = await fetch(`${BASE_URL}/despesas/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (res.ok) {
      alert("Despesa atualizada com sucesso!");
      window.location.href = "despesas.html";
    } else {
      alert("Erro ao editar despesa.");
    }
  });
}
initEditarDespesa();


async function excluirDespesa(id) {
  if (!confirm("Deseja excluir esta despesa?")) return;
  const res = await fetch(`${BASE_URL}/despesas/${id}`, { method: "DELETE" });

  if (res.ok) {
    alert("Despesa excluída!");
    carregarDespesas();
  } else {
    alert("Erro ao excluir despesa.");
  }
}
