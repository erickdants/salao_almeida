// servicos.js
try { requireAuth(); } catch (e) {}

const formS = document.getElementById("servicoForm");
const tbodyS = document.getElementById("servicosTbody");
const inNomeS = document.getElementById("nome_servico");
const inPrecoS = document.getElementById("preco_servico");
const inServicoId = document.getElementById("servicoId");

async function listarServicos() {
  try {
    const res = await fetch(`${BASE_URL}/servicos`);
    const data = await handleResponse(res);
    tbodyS.innerHTML = "";
    data.forEach(s => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${s.cod_servico ?? s.Cod_servico ?? ""}</td>
        <td>${s.Nome_servico ?? s.nome_servico ?? ""}</td>
        <td>${s.preco_servico ?? s.Preco_servico ?? ""}</td>
        <td>
          <button class="btn btn-sm btn-primary me-1" data-id="${s.cod_servico ?? s.Cod_servico ?? ""}" data-action="edit">Editar</button>
          <button class="btn btn-sm btn-danger" data-id="${s.cod_servico ?? s.Cod_servico ?? ""}" data-action="del">Excluir</button>
        </td>
      `;
      tbodyS.appendChild(tr);
    });
    tbodyS.querySelectorAll("button").forEach(b=>b.addEventListener("click", onAction));
  } catch (err) { console.error(err); showToast("Erro ao carregar serviços"); }
}

async function onAction(e) {
  const id = e.currentTarget.dataset.id;
  const action = e.currentTarget.dataset.action;
  const row = e.currentTarget.closest("tr");
  if (action === "edit") {
    inServicoId.value = id;
    inNomeS.value = row.cells[1].innerText;
    inPrecoS.value = row.cells[2].innerText;
  } else {
    if (!confirm("Excluir serviço?")) return;
    try { await handleResponse(await fetch(`${BASE_URL}/servicos/${encodeURIComponent(id)}`,{method:"DELETE"})); listarServicos(); showToast("Excluído"); }
    catch (err) { console.error(err); showToast("Erro ao excluir"); }
  }
}

formS.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = { Nome_servico: inNomeS.value.trim(), preco_servico: inPrecoS.value ? Number(inPrecoS.value) : null };
  try {
    if (inServicoId.value) {
      await handleResponse(await fetch(`${BASE_URL}/servicos/${encodeURIComponent(inServicoId.value)}`, { method:"PUT", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)}));
      showToast("Atualizado");
      inServicoId.value = "";
    } else {
      await handleResponse(await fetch(`${BASE_URL}/servicos`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)}));
      showToast("Criado");
    }
    formS.reset(); listarServicos();
  } catch (err) { console.error(err); showToast("Erro ao salvar"); }
});

document.getElementById("backDash").addEventListener("click", ()=> window.location.href="dashboard.html");
listarServicos();
