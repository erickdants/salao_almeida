import express from "express";
import {
  listarFuncionarios,
  cadastrarFuncionario,
  buscarFuncionarioCompleto,
  editarFuncionario,
  excluirFuncionario
} from "../controllers/funcionarioController.js";

const router = express.Router();

router.get("/", listarFuncionarios);
router.post("/", cadastrarFuncionario);
router.get("/:cod_f/completo", buscarFuncionarioCompleto);
router.put("/:cod_f", editarFuncionario);
router.delete("/:cod_f", excluirFuncionario);

export default router;
