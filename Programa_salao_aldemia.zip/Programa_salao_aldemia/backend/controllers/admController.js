import pool from "../db.js";


export const validarADM = async (req, res) => {
  const { ID_usuario, senha } = req.body;

  try {
    const r = await pool.query(
      `SELECT u.id_usuario
       FROM Usuario u
       INNER JOIN ADM a ON a.id_usuario = u.id_usuario
       WHERE u.id_usuario = $1 AND u.senha_usuario = $2`,
       [ID_usuario, senha]
    );

    if (!r.rows.length) {
      return res.status(401).send("Credenciais inválidas");
    }

    res.send("OK");

  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao validar administrador");
  }
};



export const cadastrarADM = async (req, res) => {
  const { nome_usuario, senha_usuario } = req.body;

  try {
    
    const r = await pool.query(`
        SELECT id_usuario FROM Usuario
        WHERE id_usuario LIKE '2%%%%%%%'
        ORDER BY id_usuario DESC LIMIT 1
    `);

    let novoId = r.rows.length ? (Number(r.rows[0].id_usuario) + 1) : 20000001;
    novoId = String(novoId).padStart(8, "0");

    await pool.query(
      `INSERT INTO Usuario (nome_usuario, id_usuario, senha_usuario)
       VALUES ($1, $2, $3)`,
      [nome_usuario, novoId, senha_usuario]
    );

    await pool.query(
      `INSERT INTO ADM (id_usuario)
       VALUES ($1)`,
       [novoId]
    );

    res.status(201).json({ message: "ADM criado!", id_usuario: novoId });

  } catch (err) {
    console.error(err);
    res.status(500).send("Erro ao cadastrar administrador");
  }
};
