import express from "express";
import {
  listarServicos,
  cadastrarServico,
  buscarServicoCompleto,
  editarServico,
  excluirServico,
  listarUtilizacoesServico,
  reativarServico
} from "../controllers/servicoController.js";

const router = express.Router();

router.get("/", listarServicos);                 
router.post("/", cadastrarServico);
router.get("/:cod", buscarServicoCompleto);
router.put("/:cod", editarServico);
router.delete("/:cod", excluirServico);          
router.put("/:cod/reativar", reativarServico);   
router.get("/:cod/utilizacoes", listarUtilizacoesServico);

export default router;
