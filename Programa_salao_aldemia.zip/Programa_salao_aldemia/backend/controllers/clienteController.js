
import pool from "../db.js";


export const listarClientes = async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT * FROM cliente ORDER BY cod_cli DESC
    `);

    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar clientes:", err);
    res.status(500).send("Erro ao listar clientes");
  }
};


export const cadastrarCliente = async (req, res) => {

  
  const {
    cliente,
    anamnese_ficha,
    anamnese_historico_pessoal,
    anamnese_cuidados_cabelo,
    anamnese_exame_fisico
  } = req.body;

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    
    const cliRes = await client.query(
      `INSERT INTO cliente (nome_cli, idade_cli, rua_cli, bairro_cli, cidade_cli, estado_cli)
       VALUES ($1,$2,$3,$4,$5,$6)
       RETURNING cod_cli`,
      [
        cliente.nome_cli,
        cliente.idade_cli,
        cliente.rua_cli,
        cliente.bairro_cli,
        cliente.cidade_cli,
        cliente.estado_cli
      ]
    );

    const cod_cli = cliRes.rows[0].cod_cli;

    
    await client.query(
      `INSERT INTO anamnese_ficha
      (cod_cli, queixa_pincipal, alteracao_acomete_corpo, alteracao_acomete_corpo_afirmativo,
        tempo_alteracao, problema_esta, cabelo_ficou, alteracao_cabelo,
        teve_outras_crises, quando_teve_outras_crises, relatorio)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
      [
        cod_cli,
        anamnese_ficha.queixa_pincipal,
        anamnese_ficha.alteracao_acomete_corpo,
        anamnese_ficha.alteracao_acomete_corpo_afirmativo,
        anamnese_ficha.tempo_alteracao,
        anamnese_ficha.problema_esta,
        anamnese_ficha.cabelo_ficou,
        anamnese_ficha.alteracao_cabelo,
        anamnese_ficha.teve_outras_crises,
        anamnese_ficha.quando_teve_outras_crises,
        anamnese_ficha.relatorio
      ]
    );

    
    await client.query(
      `INSERT INTO anamnese_historico_pessoal
      (cod_cli, alguma_doenca, qual_doenca, frequencia_modo_lavagem_cabelo,
        cosmeticos_utilizados, alergia_cosmetico_medicamento,
        qual_alergia_cosmetico_medicamento, parente_com_calvicie)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
      [
        cod_cli,
        anamnese_historico_pessoal.alguma_doenca,
        anamnese_historico_pessoal.qual_doenca,
        anamnese_historico_pessoal.frequencia_modo_lavagem_cabelo,
        anamnese_historico_pessoal.cosmeticos_utilizados,
        anamnese_historico_pessoal.alergia_cosmetico_medicamento,
        anamnese_historico_pessoal.qual_alergia_cosmetico_medicamento,
        anamnese_historico_pessoal.parente_com_calvicie
      ]
    );

    
    await client.query(
      `INSERT INTO anamnese_cuidados_cabelo
      (cod_cli, faz_quimica, qual_quimica, frequencia_quimica, utiliza_acessorio)
      VALUES ($1,$2,$3,$4,$5)`,
      [
        cod_cli,
        anamnese_cuidados_cabelo.faz_quimica,
        anamnese_cuidados_cabelo.qual_quimica,
        anamnese_cuidados_cabelo.frequencia_quimica,
        anamnese_cuidados_cabelo.utiliza_acessorio
      ]
    );

    
    await client.query(
      `INSERT INTO anamnese_exame_fisico
      (cod_cli, couro_capiludo_apresenta, presenca_couro_capiludo,
        comprimento_cabelo_igual, cabelo_possui, pontas_cabelo,
        fios_encontrados, cor_cabelo, natural_cabelo, tipo_cabelo,
        texturizacao_cabelo, curvatura_cabelo, espessura_cabelo,
        densidade_cabelo, porosidade_cabelo, elasticidade_cabelo,
        complicacoes_cabelo, observacao_complementar)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)`,
      [
        cod_cli,
        anamnese_exame_fisico.couro_capiludo_apresenta,
        anamnese_exame_fisico.presenca_couro_capiludo,
        anamnese_exame_fisico.comprimento_cabelo_igual,
        anamnese_exame_fisico.cabelo_possui,
        anamnese_exame_fisico.pontas_cabelo,
        anamnese_exame_fisico.fios_encontrados,
        anamnese_exame_fisico.cor_cabelo,
        anamnese_exame_fisico.natural_cabelo,
        anamnese_exame_fisico.tipo_cabelo,
        anamnese_exame_fisico.texturizacao_cabelo,
        anamnese_exame_fisico.curvatura_cabelo,
        anamnese_exame_fisico.espessura_cabelo,
        anamnese_exame_fisico.densidade_cabelo,
        anamnese_exame_fisico.porosidade_cabelo,
        anamnese_exame_fisico.elasticidade_cabelo,
        anamnese_exame_fisico.complicacoes_cabelo,
        anamnese_exame_fisico.observacao_complementar
      ]
    );

    await client.query("COMMIT");

    res.status(201).json({ message: "Cliente cadastrado com sucesso!", cod_cli });

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao cadastrar cliente:", err);
    res.status(500).send("Erro ao cadastrar cliente");
  } finally {
    client.release();
  }
};


export const buscarClienteCompleto = async (req, res) => {
  const { id } = req.params;

  try {
    const cliente = await pool.query(
      "SELECT * FROM cliente WHERE cod_cli = $1",
      [id]
    );

    if (!cliente.rows.length) {
      return res.status(404).send("Cliente não encontrado");
    }

    const ficha = await pool.query(
      "SELECT * FROM anamnese_ficha WHERE cod_cli = $1 ORDER BY cont_af ASC",
      [id]
    );
    const historico = await pool.query(
      "SELECT * FROM anamnese_historico_pessoal WHERE cod_cli = $1 ORDER BY cont_ahp ASC",
      [id]
    );
    const cuidados = await pool.query(
      "SELECT * FROM anamnese_cuidados_cabelo WHERE cod_cli = $1 ORDER BY cont_acc ASC",
      [id]
    );
    const exame = await pool.query(
      "SELECT * FROM anamnese_exame_fisico WHERE cod_cli = $1 ORDER BY cont ASC",
      [id]
    );

    res.json({
      cliente: cliente.rows[0],
      anamnese_ficha: ficha.rows,                  
      anamnese_historico_pessoal: historico.rows,  
      anamnese_cuidados_cabelo: cuidados.rows,     
      anamnese_exame_fisico: exame.rows           
    });

  } catch (err) {
    console.error("Erro ao buscar cliente completo:", err);
    res.status(500).send("Erro ao buscar cliente completo");
  }
};


export const excluirCliente = async (req, res) => {
  const { id } = req.params;

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    
    await client.query(
      "DELETE FROM anamnese_ficha WHERE cod_cli = $1",
      [id]
    );

    
    await client.query(
      "DELETE FROM anamnese_historico_pessoal WHERE cod_cli = $1",
      [id]
    );

    
    await client.query(
      "DELETE FROM anamnese_cuidados_cabelo WHERE cod_cli = $1",
      [id]
    );

    
    await client.query(
      "DELETE FROM anamnese_exame_fisico WHERE cod_cli = $1",
      [id]
    );

    
    await client.query(
      "DELETE FROM cliente WHERE cod_cli = $1",
      [id]
    );

    await client.query("COMMIT");
    res.send("Cliente e todas as anamneses foram excluídos com sucesso!");

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao excluir cliente:", err);
    res.status(500).send("Erro ao excluir cliente");
  } finally {
    client.release();
  }
};



export const editarCliente = async (req, res) => {
  const { id } = req.params;
  const {
    cliente,
    anamnese_ficha,
    anamnese_historico_pessoal,
    anamnese_cuidados_cabelo,
    anamnese_exame_fisico
  } = req.body;

  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    await client.query(
      `UPDATE cliente SET nome_cli=$1, idade_cli=$2, rua_cli=$3, bairro_cli=$4,
       cidade_cli=$5, estado_cli=$6 WHERE cod_cli=$7`,
      [
        cliente.nome_cli,
        cliente.idade_cli,
        cliente.rua_cli,
        cliente.bairro_cli,
        cliente.cidade_cli,
        cliente.estado_cli,
        id
      ]
    );

    await client.query(
      `UPDATE anamnese_ficha
        SET queixa_pincipal=$1, alteracao_acomete_corpo=$2,
            alteracao_acomete_corpo_afirmativo=$3,
            tempo_alteracao=$4, problema_esta=$5, cabelo_ficou=$6,
            alteracao_cabelo=$7, teve_outras_crises=$8,
            quando_teve_outras_crises=$9, relatorio=$10
       WHERE cod_cli=$11`,
      [
        anamnese_ficha.queixa_pincipal,
        anamnese_ficha.alteracao_acomete_corpo,
        anamnese_ficha.alteracao_acomete_corpo_afirmativo,
        anamnese_ficha.tempo_alteracao,
        anamnese_ficha.problema_esta,
        anamnese_ficha.cabelo_ficou,
        anamnese_ficha.alteracao_cabelo,
        anamnese_ficha.teve_outras_crises,
        anamnese_ficha.quando_teve_outras_crises,
        anamnese_ficha.relatorio,
        id
      ]
    );

    await client.query(
      `UPDATE anamnese_historico_pessoal
        SET alguma_doenca=$1, qual_doenca=$2, frequencia_modo_lavagem_cabelo=$3,
            cosmeticos_utilizados=$4, alergia_cosmetico_medicamento=$5,
            qual_alergia_cosmetico_medicamento=$6, parente_com_calvicie=$7
       WHERE cod_cli=$8`,
      [
        anamnese_historico_pessoal.alguma_doenca,
        anamnese_historico_pessoal.qual_doenca,
        anamnese_historico_pessoal.frequencia_modo_lavagem_cabelo,
        anamnese_historico_pessoal.cosmeticos_utilizados,
        anamnese_historico_pessoal.alergia_cosmetico_medicamento,
        anamnese_historico_pessoal.qual_alergia_cosmetico_medicamento,
        anamnese_historico_pessoal.parente_com_calvicie,
        id
      ]
    );

    await client.query(
      `UPDATE anamnese_cuidados_cabelo
        SET faz_quimica=$1, qual_quimica=$2, frequencia_quimica=$3, utiliza_acessorio=$4
       WHERE cod_cli=$5`,
      [
        anamnese_cuidados_cabelo.faz_quimica,
        anamnese_cuidados_cabelo.qual_quimica,
        anamnese_cuidados_cabelo.frequencia_quimica,
        anamnese_cuidados_cabelo.utiliza_acessorio,
        id
      ]
    );

    await client.query(
      `UPDATE anamnese_exame_fisico
        SET couro_capiludo_apresenta=$1, presenca_couro_capiludo=$2,
            comprimento_cabelo_igual=$3, cabelo_possui=$4, pontas_cabelo=$5,
            fios_encontrados=$6, cor_cabelo=$7, natural_cabelo=$8,
            tipo_cabelo=$9, texturizacao_cabelo=$10, curvatura_cabelo=$11,
            espessura_cabelo=$12, densidade_cabelo=$13, porosidade_cabelo=$14,
            elasticidade_cabelo=$15, complicacoes_cabelo=$16,
            observacao_complementar=$17
        WHERE cod_cli=$18`,
      [
        anamnese_exame_fisico.couro_capiludo_apresenta,
        anamnese_exame_fisico.presenca_couro_capiludo,
        anamnese_exame_fisico.comprimento_cabelo_igual,
        anamnese_exame_fisico.cabelo_possui,
        anamnese_exame_fisico.pontas_cabelo,
        anamnese_exame_fisico.fios_encontrados,
        anamnese_exame_fisico.cor_cabelo,
        anamnese_exame_fisico.natural_cabelo,
        anamnese_exame_fisico.tipo_cabelo,
        anamnese_exame_fisico.texturizacao_cabelo,
        anamnese_exame_fisico.curvatura_cabelo,
        anamnese_exame_fisico.espessura_cabelo,
        anamnese_exame_fisico.densidade_cabelo,
        anamnese_exame_fisico.porosidade_cabelo,
        anamnese_exame_fisico.elasticidade_cabelo,
        anamnese_exame_fisico.complicacoes_cabelo,
        anamnese_exame_fisico.observacao_complementar,
        id
      ]
    );

    await client.query("COMMIT");
    res.send("Cliente atualizado com sucesso!");

  } catch (err) {
    await client.query("ROLLBACK");
    console.error("Erro ao editar cliente:", err);
    res.status(500).send("Erro ao editar cliente");
  } finally {
    client.release();
  }
};
