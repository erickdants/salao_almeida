import express from "express";
import {
  loginUsuario,
  listarUsuarios,
  criarUsuario,
  atualizarUsuario,
  excluirUsuario,
  obterUsuarioPorId
} from "../controllers/usuarioController.js";

const router = express.Router();

router.post("/login", loginUsuario);
router.get("/", listarUsuarios);
router.post("/", criarUsuario);
router.get("/:id", obterUsuarioPorId);
router.put("/:id", atualizarUsuario);
router.delete("/:id", excluirUsuario);

export default router;
