import express from "express";
import {
  listarAgendamentos,
  cadastrarAgendamento,
  atualizarAgendamento,
  excluirAgendamento
} from "../controllers/agendaController.js";

const router = express.Router();

router.get("/", listarAgendamentos);
router.post("/", cadastrarAgendamento);
router.put("/:id", atualizarAgendamento);
router.delete("/:id", excluirAgendamento);

export default router;
