import express from "express";
import { listarClientes, criarClienteCompleto, atualizarCliente, excluirCliente } from "../controllers/clienteController.js";

const router = express.Router();

router.get("/", listarClientes);
router.post("/", criarClienteCompleto);
router.put("/:id", atualizarCliente);
router.delete("/:id", excluirCliente);

export default router;