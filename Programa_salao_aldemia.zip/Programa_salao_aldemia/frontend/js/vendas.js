// vendas.js
try { requireAuth(); } catch (e) {}

const formV = document.getElementById("vendaForm");
const tbodyV = document.getElementById("vendasTbody");
const inVcodCli = document.getElementById("v_cod_cli");
const inVvalor = document.getElementById("v_valor");

async function listarVendas() {
  try {
    const res = await fetch(`${BASE_URL}/vendas`);
    const data = await handleResponse(res);
    tbodyV.innerHTML = "";
    data.forEach(v => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${v.cod_vendas ?? v.Cod_vendas ?? ""}</td>
        <td>${v.Cod_cli ?? v.cod_cli ?? ""}</td>
        <td>${v.Valor_total ?? v.valor_total ?? ""}</td>
        <td>${v.data_venda ?? v.Data_venda ?? ""}</td>
        <td>
          <button class="btn btn-sm btn-danger" data-id="${v.cod_vendas ?? v.Cod_vendas ?? ""}" data-action="del">Excluir</button>
        </td>`;
      tbodyV.appendChild(tr);
    });
    tbodyV.querySelectorAll("button[data-action=del]").forEach(b => b.addEventListener("click", async (e) => {
      const id = e.currentTarget.dataset.id;
      if (!confirm("Excluir venda?")) return;
      try { await handleResponse(await fetch(`${BASE_URL}/vendas/${encodeURIComponent(id)}`, { method: "DELETE" })); listarVendas(); showToast("Venda excluída"); }
      catch (err) { console.error(err); showToast("Erro ao excluir"); }
    }));
  } catch (err) { console.error(err); showToast("Erro ao carregar vendas"); }
}

formV.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = { Cod_cli: inVcodCli.value.trim(), Valor_total: inVvalor.value ? Number(inVvalor.value) : 0 };
  try {
    await handleResponse(await fetch(`${BASE_URL}/vendas`, { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(payload) }));
    showToast("Venda registrada");
    formV.reset();
    listarVendas();
  } catch (err) { console.error(err); showToast("Erro ao registrar venda"); }
});

document.getElementById("backDash").addEventListener("click", ()=> window.location.href="dashboard.html");
listarVendas();
