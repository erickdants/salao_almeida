import pool from "../db.js";

export const listarAgendamentos = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM Agenda ORDER BY id_agendamento ASC");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const cadastrarAgendamento = async (req, res) => {
  const { data_agendamento, hora_agendamento, id_cliente, id_servico } = req.body;
  try {
    const result = await pool.query(
      "INSERT INTO Agenda (data_agendamento, hora_agendamento, id_cliente, id_servico) VALUES ($1, $2, $3, $4) RETURNING *",
      [data_agendamento, hora_agendamento, id_cliente, id_servico]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const atualizarAgendamento = async (req, res) => {
  const { id } = req.params;
  const { data_agendamento, hora_agendamento, id_cliente, id_servico } = req.body;
  try {
    const result = await pool.query(
      "UPDATE Agenda SET data_agendamento=$1, hora_agendamento=$2, id_cliente=$3, id_servico=$4 WHERE id_agendamento=$5 RETURNING *",
      [data_agendamento, hora_agendamento, id_cliente, id_servico, id]
    );
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const excluirAgendamento = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM Agenda WHERE id_agendamento=$1", [id]);
    res.json({ mensagem: "Agendamento removido com sucesso!" });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};
