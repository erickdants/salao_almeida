import pool from "../db.js";

export const criarClienteCompleto = async (req, res) => {
  const { cliente, anamnese_ficha, anamnese_historico_pessoal, anamnese_cuidados_cabelo, anamnese_exame_fisico } = req.body;
  if (!cliente || !cliente.nome_cli) return res.status(400).json({ erro: "Dados do cliente obrigatórios" });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const rMax = await client.query("SELECT COALESCE(MAX(Cod_cli), 0) + 1 AS novo FROM Cliente");
    const novoCod = rMax.rows[0].novo;

    await client.query(
      `INSERT INTO Cliente (Cod_cli, nome_cli, idade_cli, rua_cli, bairro_cli, cidade_cli, estado_cli)
       VALUES ($1,$2,$3,$4,$5,$6,$7)`,
      [
        novoCod,
        cliente.nome_cli || null,
        cliente.idade_cli || null,
        cliente.rua_cli || null,
        cliente.bairro_cli || null,
        cliente.cidade_cli || null,
        cliente.estado_cli || null
      ]
    );

    if (anamnese_ficha) {
      await client.query(
        `INSERT INTO Anamnese_ficha (Cod_cli, queixa_pincipal, alteracao_acomete_corpo, alteracao_acomete_corpo_afirmativo, tempo_alteracao, problema_esta, cabelo_ficou, alteracao_cabelo, teve_outras_crises, quando_teve_outras_crises, relatorio)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11)`,
        [
          novoCod,
          anamnese_ficha.queixa_pincipal || null,
          anamnese_ficha.alteracao_acomete_corpo || false,
          anamnese_ficha.alteracao_acomete_corpo_afirmativo || null,
          anamnese_ficha.tempo_alteracao || null,
          anamnese_ficha.problema_esta || null,
          anamnese_ficha.cabelo_ficou || null,
          anamnese_ficha.alteracao_cabelo || null,
          anamnese_ficha.teve_outras_crises || false,
          anamnese_ficha.quando_teve_outras_crises || null,
          anamnese_ficha.relatorio || null
        ]
      );
    }

    if (anamnese_historico_pessoal) {
      await client.query(
        `INSERT INTO Anamnese_historico_pessoal (Cod_cli, alguma_doenca, qual_doenca, frequencia_modo_lavagem_cabelo, cosmeticos_utilizados, alergia_cosmetico_medicamento, qual_alergia_cosmetico_medicamento, parente_com_calvicie)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8)`,
        [
          novoCod,
          anamnese_historico_pessoal.alguma_doenca || false,
          anamnese_historico_pessoal.qual_doenca || null,
          anamnese_historico_pessoal.frequencia_modo_lavagem_cabelo || null,
          anamnese_historico_pessoal.cosmeticos_utilizados || null,
          anamnese_historico_pessoal.alergia_cosmetico_medicamento || null,
          anamnese_historico_pessoal.qual_alergia_cosmetico_medicamento || null,
          anamnese_historico_pessoal.parente_com_calvicie || false
        ]
      );
    }

    if (anamnese_cuidados_cabelo) {
      await client.query(
        `INSERT INTO Anamnese_cuidados_cabelo (Cod_cli, faz_quimica, qual_quimica, frequencia_quimica, utiliza_acessorio)
         VALUES ($1,$2,$3,$4,$5)`,
        [
          novoCod,
          anamnese_cuidados_cabelo.faz_quimica || false,
          anamnese_cuidados_cabelo.qual_quimica || null,
          anamnese_cuidados_cabelo.frequencia_quimica || null,
          anamnese_cuidados_cabelo.utiliza_acessorio || null
        ]
      );
    }

    if (anamnese_exame_fisico) {
      await client.query(
        `INSERT INTO Anamnese_exame_fisico (Cod_cli, Couro_capiludo_apresenta, Presenca_couro_capiludo, Comprimento_cabelo_igual, Cabelo_possui, Pontas_cabelo, Fios_encontrados, Cor_cabelo, Natural_cabelo, Tipo_cabelo, Texturização_cabelo, Curvatura_cabelo, Espessura_cabelo, Densidade_cabelo, Porosidade_cabelo, Elasticidade_cabelo, Complicações_cabelo, Observacao_complementar)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18)`,
        [
          novoCod,
          anamnese_exame_fisico.Couro_capiludo_apresenta || null,
          anamnese_exame_fisico.Presenca_couro_capiludo || null,
          anamnese_exame_fisico.Comprimento_cabelo_igual || false,
          anamnese_exame_fisico.Cabelo_possui || null,
          anamnese_exame_fisico.Pontas_cabelo || false,
          anamnese_exame_fisico.Fios_encontrados || null,
          anamnese_exame_fisico.Cor_cabelo || null,
          anamnese_exame_fisico.Natural_cabelo || false,
          anamnese_exame_fisico.Tipo_cabelo || null,
          anamnese_exame_fisico["Texturização_cabelo"] || null,
          anamnese_exame_fisico.Curvatura_cabelo || null,
          anamnese_exame_fisico.Espessura_cabelo || null,
          anamnese_exame_fisico.Densidade_cabelo || null,
          anamnese_exame_fisico.Porosidade_cabelo || null,
          anamnese_exame_fisico.Elasticidade_cabelo || null,
          anamnese_exame_fisico.Complicações_cabelo || null,
          anamnese_exame_fisico.Observacao_complementar || null
        ]
      );
    }

    await client.query("COMMIT");
    res.status(201).json({ sucesso: true, Cod_cli: novoCod });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("criarClienteCompleto:", err);
    res.status(500).json({ erro: err.message });
  } finally {
    client.release();
  }
};

export const listarClientes = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM Cliente ORDER BY Cod_cli");
    res.json(result.rows);
  } catch (err) {
    console.error("listarClientes:", err);
    res.status(500).json({ erro: err.message });
  }
};


export const atualizarCliente = async (req, res) => {
  const { id } = req.params;
  const { nome_cli, idade_cli, rua_cli, bairro_cli, cidade_cli, estado_cli } = req.body;

  try {
    await pool.query(
      `UPDATE Cliente SET nome_cli=$1, idade_cli=$2, rua_cli=$3, bairro_cli=$4, cidade_cli=$5, estado_cli=$6 WHERE Cod_cli=$7`,
      [nome_cli, idade_cli, rua_cli, bairro_cli, cidade_cli, estado_cli, id]
    );
    res.json({ sucesso: true });
  } catch (err) {
    console.error("atualizarCliente:", err);
    res.status(500).json({ erro: err.message });
  }
};


export const excluirCliente = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM Cliente WHERE Cod_cli=$1", [id]);
    res.json({ sucesso: true });
  } catch (err) {
    console.error("excluirCliente:", err);
    res.status(500).json({ erro: err.message });
  }
};

