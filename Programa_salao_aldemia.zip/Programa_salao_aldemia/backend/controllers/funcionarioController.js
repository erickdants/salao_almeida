import pool from "../db.js";

export const listarFuncionarios = async (req, res) => {
  try {
    const q = await pool.query(
      `SELECT f.ID_usuario, f.Cod_f, f.Status, f.CH, u.nome_usuario
       FROM Funcionario f
       LEFT JOIN Usuario u ON u.ID_usuario = f.ID_usuario
       ORDER BY f.Cod_f`
    );
    res.json(q.rows);
  } catch (err) {
    console.error("listarFuncionarios:", err);
    res.status(500).json({ erro: err.message });
  }
};

export const obterFuncionarioPorId = async (req, res) => {
  const id = req.params.id;
  try {
    const q = await pool.query(
      `SELECT f.ID_usuario, f.Cod_f, f.Status, f.CH, u.nome_usuario
       FROM Funcionario f
       LEFT JOIN Usuario u ON u.ID_usuario = f.ID_usuario
       WHERE f.ID_usuario = $1`,
      [id]
    );
    if (q.rowCount === 0) return res.status(404).json({ erro: "Funcionário não encontrado" });
    res.json(q.rows[0]);
  } catch (err) {
    console.error("obterFuncionarioPorId:", err);
    res.status(500).json({ erro: err.message });
  }
};

export const criarFuncionario = async (req, res) => {
  const { ID_usuario, Cod_f, Status = null, CH = 0, Cod_agenda = null } = req.body;
  if (!ID_usuario || !Cod_f) return res.status(400).json({ erro: "ID_usuario e Cod_f são obrigatórios" });

  try {
    await pool.query(
      "INSERT INTO Funcionario (ID_usuario, Cod_f, Status, CH, Cod_agenda) VALUES ($1,$2,$3,$4,$5)",
      [ID_usuario, Cod_f, Status, CH, Cod_agenda]
    );
    res.status(201).json({ sucesso: true, mensagem: "Funcionário criado" });
  } catch (err) {
    console.error("criarFuncionario:", err);
    res.status(500).json({ erro: err.message });
  }
};


export const listarAgendaDoFuncionario = async (req, res) => {
  const id = req.params.id;
  try {
    
    const q = await pool.query(
      `SELECT a.Cod_agenda, a.Data_agenda, c.Cod_cli, c.nome_cli
       FROM Funci_cliente fc
       JOIN Agenda a ON a.Cod_cli = fc.Cod_cli
       JOIN Cliente c ON c.Cod_cli = fc.Cod_cli
       WHERE fc.Cod_f = $1
       ORDER BY a.Data_agenda DESC`,
      [id]
    );
    res.json(q.rows);
  } catch (err) {
    console.error("listarAgendaDoFuncionario:", err);
    res.status(500).json({ erro: err.message });
  }
};

export const registrarAtendimento = async (req, res) => {
  const Cod_f = parseInt(req.params.id, 10); 
  const { Cod_cli, Data_acontecimento = null } = req.body;
  if (!Cod_f || !Cod_cli) return res.status(400).json({ erro: "Cod_f (param) e Cod_cli (body) são obrigatórios" });

  try {
    await pool.query(
      "INSERT INTO Funci_cliente (Cod_cli, Cod_f, Data_acontecimento) VALUES ($1, $2, $3)",
      [Cod_cli, Cod_f, Data_acontecimento]
    );
    res.status(201).json({ sucesso: true, mensagem: "Atendimento registrado" });
  } catch (err) {
    console.error("registrarAtendimento:", err);
    
    res.status(500).json({ erro: err.message });
  }
};
