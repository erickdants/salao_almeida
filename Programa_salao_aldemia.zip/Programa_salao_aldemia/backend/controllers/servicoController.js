import pool from "../db.js";


export const listarServicos = async (req, res) => {
  const { todos } = req.query;

  try {
    const query = todos === "true"
      ? `SELECT * FROM Servico ORDER BY Cod_servico`
      : `SELECT * FROM Servico WHERE ativo = TRUE ORDER BY Cod_servico`;

    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar serviços:", err);
    res.status(500).send("Erro ao listar serviços");
  }
};


export const cadastrarServico = async (req, res) => {
  const { nome_servico, descricao } = req.body;

  try {
    await pool.query(
      `INSERT INTO Servico (Nome_servico, descricao, ativo)
       VALUES ($1, $2, TRUE)`,
      [nome_servico, descricao]
    );

    res.status(201).send("Serviço cadastrado com sucesso!");
  } catch (err) {
    console.error("Erro cadastrar serviço:", err);
    res.status(500).send("Erro ao cadastrar serviço");
  }
};


export const buscarServicoCompleto = async (req, res) => {
  const { cod } = req.params;

  try {
    const result = await pool.query(
      `SELECT * FROM Servico WHERE Cod_servico = $1`,
      [cod]
    );

    if (!result.rows.length) {
      return res.status(404).send("Serviço não encontrado");
    }

    res.json(result.rows[0]);
  } catch (err) {
    console.error("Erro buscar serviço:", err);
    res.status(500).send("Erro ao buscar serviço");
  }
};


export const editarServico = async (req, res) => {
  const { cod } = req.params;
  const { nome_servico, descricao } = req.body;

  try {
    await pool.query(
      `UPDATE Servico
       SET Nome_servico = $1,
           descricao = $2
       WHERE Cod_servico = $3`,
      [nome_servico, descricao, cod]
    );

    res.send("Serviço atualizado com sucesso!");
  } catch (err) {
    console.error("Erro editar serviço:", err);
    res.status(500).send("Erro ao editar serviço");
  }
};


export const excluirServico = async (req, res) => {
  const { cod } = req.params;

  try {
    await pool.query(
      `UPDATE Servico SET ativo = FALSE WHERE Cod_servico = $1`,
      [cod]
    );

    res.send("Serviço desativado!");
  } catch (err) {
    console.error("Erro desativar serviço:", err);
    res.status(500).send("Erro ao desativar serviço");
  }
};

/* ================= REATIVAR ================= */
export const reativarServico = async (req, res) => {
  const { cod } = req.params;

  try {
    await pool.query(
      `UPDATE Servico SET ativo = TRUE WHERE Cod_servico = $1`,
      [cod]
    );

    res.send("Serviço reativado!");
  } catch (err) {
    console.error("Erro reativar serviço:", err);
    res.status(500).send("Erro ao reativar serviço");
  }
};

export const listarUtilizacoesServico = async (req, res) => {
  const { cod } = req.params;

  try {
    const result = await pool.query(
      `
      SELECT
        cod_agenda,
        quant_servico
      FROM Agenda_utilizara_servico
      WHERE cod_servico = $1
      `,
      [cod]
    );

    res.json(result.rows);
  } catch (err) {
    console.error("Erro listar utilizações do serviço:", err);
    res.status(500).send("Erro ao listar utilizações do serviço");
  }
};
