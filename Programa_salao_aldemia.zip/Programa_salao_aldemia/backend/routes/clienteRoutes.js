import express from "express";
import {
  listarClientes,
  cadastrarCliente,
  buscarClienteCompleto,
  editarCliente,
  excluirCliente
} from "../controllers/clienteController.js";

const router = express.Router();

router.get("/", listarClientes);
router.post("/", cadastrarCliente);
router.get("/:id/completo", buscarClienteCompleto);
router.put("/:id", editarCliente);
router.delete("/:id", excluirCliente);

export default router;
