import express from "express";
import { validarADM, cadastrarADM } from "../controllers/admController.js";

const router = express.Router();

router.post("/validar", validarADM);
router.post("/", cadastrarADM);

export default router;
