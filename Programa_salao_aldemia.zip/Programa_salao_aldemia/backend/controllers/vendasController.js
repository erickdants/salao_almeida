import pool from "../db.js";

export const listarVendas = async (req, res) => {
  try {
    const result = await pool.query("SELECT * FROM Venda ORDER BY id_venda ASC");
    res.json(result.rows);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const registrarVenda = async (req, res) => {
  const { id_cliente, id_produto, quantidade, valor_total } = req.body;
  try {
    const result = await pool.query(
      "INSERT INTO Venda (id_cliente, id_produto, quantidade, valor_total) VALUES ($1, $2, $3, $4) RETURNING *",
      [id_cliente, id_produto, quantidade, valor_total]
    );
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};

export const excluirVenda = async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM Venda WHERE id_venda=$1", [id]);
    res.json({ mensagem: "Venda removida com sucesso!" });
  } catch (err) {
    res.status(500).json({ erro: err.message });
  }
};
