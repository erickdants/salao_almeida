const BASE_URL = "http://localhost:3000";


async function carregarServicos() {
  const tbody = document.querySelector("#tabelaServicos tbody");
  if (!tbody) return;

  const res = await fetch(`${BASE_URL}/servicos?todos=true`);
  const servicos = await res.json();

  tbody.innerHTML = "";

  servicos.forEach(s => {
    tbody.innerHTML += `
      <tr>
        <td>${s.cod_servico}</td>
        <td>${s.nome_servico}</td>
        <td>${s.descricao ?? ""}</td>
        <td>
          ${s.ativo
            ? `<span class="badge bg-success">Ativo</span>`
            : `<span class="badge bg-secondary">Inativo</span>`}
        </td>
        <td>
          <button class="btn btn-sm btn-primary me-1"
            onclick="editarServico(${s.cod_servico})">
            Editar
          </button>

          <button class="btn btn-sm btn-secondary me-1"
            onclick="verAgendasServico(${s.cod_servico}, '${s.nome_servico}')">
            Ver Agendas
          </button>

          ${s.ativo
            ? `<button class="btn btn-sm btn-danger"
                onclick="desativarServico(${s.cod_servico})">
                Desativar
              </button>`
            : `<button class="btn btn-sm btn-success"
                onclick="reativarServico(${s.cod_servico})">
                Reativar
              </button>`}
        </td>
      </tr>
    `;
  });
}


function editarServico(cod) {
  localStorage.setItem("servico_editar", cod);
  window.location.href = "servico_editar.html";
}

async function desativarServico(cod) {
  if (!confirm("Desativar serviço?")) return;
  await fetch(`${BASE_URL}/servicos/${cod}`, { method: "DELETE" });
  carregarServicos();
}

async function reativarServico(cod) {
  if (!confirm("Reativar serviço?")) return;
  await fetch(`${BASE_URL}/servicos/${cod}/reativar`, { method: "PUT" });
  carregarServicos();
}


async function verAgendasServico(cod, nome) {

  document.getElementById("usoServicoTitulo").textContent = `(${nome})`;
  document.getElementById("panelUsoServico").style.display = "block";
  const res = await fetch(`${BASE_URL}/servicos/${cod}/utilizacoes`);
  const dados = await res.json();
  const tbody = document.querySelector("#tabelaUsoServico tbody");

  tbody.innerHTML = dados.length
    ? dados.map(d => `
        <tr>
          <td>${d.cod_agenda}</td>
          <td>${cod}</td>
          <td>${d.quant_servico ?? 1}</td>
        </tr>
      `).join("")
    : `
      <tr>
        <td colspan="3" class="text-center">
          Nenhuma agenda encontrada
        </td>
      </tr>
    `;
}


function fecharAgendas() {
  document.getElementById("panelAgendas").style.display = "none";
}

document.addEventListener("DOMContentLoaded", carregarServicos);



const formCadastrar = document.getElementById("formCadastrarServico");
if (formCadastrar) {
  formCadastrar.addEventListener("submit", async e => {
    e.preventDefault();

    await fetch(`${BASE_URL}/servicos`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome_servico: nome_servico.value,
        descricao: descricao.value
      })
    });

    alert("Serviço cadastrado!");
    window.location.href = "servicos_funcionario.html";
  });
}


const formEditar = document.getElementById("formEditarServico");
if (formEditar) {
  const cod = localStorage.getItem("servico_editar");

  fetch(`${BASE_URL}/servicos/${cod}`)
    .then(r => r.json())
    .then(s => {
      nome_servico.value = s.nome_servico;
      descricao.value = s.descricao ?? "";
    });

  formEditar.addEventListener("submit", async e => {
    e.preventDefault();

    await fetch(`${BASE_URL}/servicos/${cod}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        nome_servico: nome_servico.value,
        descricao: descricao.value
      })
    });

    alert("Serviço atualizado!");
    window.location.href = "servicos.html";
  });
}

document.addEventListener("DOMContentLoaded", carregarServicos);
