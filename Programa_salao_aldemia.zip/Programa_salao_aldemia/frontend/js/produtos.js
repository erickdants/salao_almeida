// produtos.js
try { requireAuth(); } catch (e) {}
const formP = document.getElementById("produtoForm");
const tbodyP = document.getElementById("produtosTbody");
const inNomeP = document.getElementById("nome_produto");
const inQuantP = document.getElementById("quant_produto");
const inProdutoId = document.getElementById("produtoId");

async function listarProdutos() {
  try {
    const res = await fetch(`${BASE_URL}/produtos`);
    const data = await handleResponse(res);
    tbodyP.innerHTML = "";
    data.forEach(p => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${p.cod_produto ?? p.Cod_produto ?? ""}</td>
        <td>${p.Nome_produto ?? p.nome_produto ?? ""}</td>
        <td>${p.quantidade_produto ?? p.Quant_prod ?? p.quant_produto ?? ""}</td>
        <td>
          <button class="btn btn-sm btn-primary me-1" data-id="${p.cod_produto ?? p.Cod_produto ?? ""}" data-action="edit">Editar</button>
          <button class="btn btn-sm btn-danger" data-id="${p.cod_produto ?? p.Cod_produto ?? ""}" data-action="del">Excluir</button>
        </td>
      `;
      tbodyP.appendChild(tr);
    });
    tbodyP.querySelectorAll("button").forEach(b=>b.addEventListener("click", onAction));
  } catch (err) { console.error(err); showToast("Erro ao carregar produtos"); }
}

async function onAction(e) {
  const id = e.currentTarget.dataset.id;
  const action = e.currentTarget.dataset.action;
  const row = e.currentTarget.closest("tr");
  if (action === "edit") {
    inProdutoId.value = id;
    inNomeP.value = row.cells[1].innerText;
    inQuantP.value = row.cells[2].innerText;
  } else {
    if (!confirm("Excluir produto?")) return;
    try { await handleResponse(await fetch(`${BASE_URL}/produtos/${encodeURIComponent(id)}`,{method:"DELETE"})); listarProdutos(); showToast("Excluído"); }
    catch (err) { console.error(err); showToast("Erro ao excluir"); }
  }
}

formP.addEventListener("submit", async (e) => {
  e.preventDefault();
  const payload = { Nome_produto: inNomeP.value.trim(), quantidade_produto: inQuantP.value ? Number(inQuantP.value) : null };
  try {
    if (inProdutoId.value) {
      await handleResponse(await fetch(`${BASE_URL}/produtos/${encodeURIComponent(inProdutoId.value)}`, { method:"PUT", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)}));
      showToast("Atualizado");
      inProdutoId.value = "";
    } else {
      await handleResponse(await fetch(`${BASE_URL}/produtos`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(payload)}));
      showToast("Criado");
    }
    formP.reset(); listarProdutos();
  } catch (err) { console.error(err); showToast("Erro ao salvar"); }
});

document.getElementById("backDash").addEventListener("click", ()=> window.location.href="dashboard.html");
listarProdutos();
