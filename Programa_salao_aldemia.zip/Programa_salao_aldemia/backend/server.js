import express from "express";
import cors from "cors";
import dotenv from "dotenv";

import usuarioRoutes from "./routes/usuarioRoutes.js";
import clienteRoutes from "./routes/clienteRoutes.js";
import agendaRoutes from "./routes/agendaRoutes.js";
import servicoRoutes from "./routes/servicoRoutes.js";
import produtoRoutes from "./routes/produtoRoutes.js";
import vendasRoutes from "./routes/vendasRoutes.js";
import funcionarioRoutes from "./routes/funcionarioRoutes.js";
import admRoutes from "./routes/admRoutes.js";
import pacoteRoutes from "./routes/pacoteRoutes.js";
import financasRoutes from "./routes/financasRoutes.js";
import despesasRoutes from "./routes/despesasRoutes.js";
import agendaFuncionarioRoutes from "./routes/agendaFuncionarioRoutes.js";
import vendasFuncionarioRoutes from "./routes/vendasFuncionarioRoutes.js";

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use("/clientes", clienteRoutes);
app.use("/agenda", agendaRoutes);
app.use("/servicos", servicoRoutes);
app.use("/produtos", produtoRoutes);
app.use("/vendas", vendasRoutes);
app.use("/usuarios", usuarioRoutes);
app.use("/funcionarios", funcionarioRoutes);
app.use("/adm", admRoutes);
app.use("/pacotes", pacoteRoutes);
app.use("/financas", financasRoutes);
app.use("/despesas", despesasRoutes);
app.use("/agendaFuncionario", agendaFuncionarioRoutes);
app.use("/vendasFuncionario", vendasFuncionarioRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));