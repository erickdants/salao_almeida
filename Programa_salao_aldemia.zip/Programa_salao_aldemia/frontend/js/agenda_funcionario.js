
const BASE_URL = "http://localhost:3000";


function getAuth() {
  try {
    return JSON.parse(localStorage.getItem("aldemia_user"));
  } catch {
    return null;
  }
}

async function resolveCodFDoUsuario() {
  const user = getAuth();
  if (!user) return null;

  if (user.cod_f || user.Cod_f) return Number(user.cod_f ?? user.Cod_f);

  const res = await fetch(`${BASE_URL}/funcionarios`);
  const funcionarios = await res.json();
  const f = funcionarios.find(
    (x) => String(x.id_usuario) === String(user.id_usuario || user.ID_usuario)
  );
  return f ? Number(f.cod_f) : null;
}


function formatarDataAgenda(data) {
  if (!data) return "—";
  const d = new Date(data); 
  const dia = String(d.getDate()).padStart(2, "0");
  const mes = String(d.getMonth() + 1).padStart(2, "0");
  const ano = d.getFullYear();
  const hora = String(d.getHours()).padStart(2, "0");
  const min = String(d.getMinutes()).padStart(2, "0");
  return `${dia}/${mes}/${ano} - ${hora}:${min}`;
}


function toDatetimeLocal(isoString) {
  if (!isoString) return "";
  const d = new Date(isoString);
  
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  return d.toISOString().slice(0, 16); 
}


const CACHE = {
  clientes: [],
  funcionarios: [],
  produtos: [],
  servicos: [],
  pacotes: [],
};


async function fetchJsonSafe(url, fallback = []) {
  try {
    const r = await fetch(url);
    if (!r.ok) return fallback;
    return await r.json();
  } catch {
    return fallback;
  }
}


async function carregarAgendas(dataFiltro = null) {
  const tbody = document.querySelector("#tabelaAgendas tbody");
  if (!tbody) return;

  const cod_f = await resolveCodFDoUsuario();
  if (!cod_f) {
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Funcionário não autenticado.</td></tr>`;
    return;
  }

  try {
    
    let url = `${BASE_URL}/agendaFuncionario/funcionario/${cod_f}`;
    if (dataFiltro) {
      url += `?data=${dataFiltro}`;
    }

    const res = await fetch(url);
    if (!res.ok) throw new Error("Erro ao buscar agendamentos");

    const agendas = await res.json();
    tbody.innerHTML = "";

    if (!agendas.length) {
      tbody.innerHTML = `<tr><td colspan="6" class="text-center">Nenhum agendamento encontrado.</td></tr>`;
      return;
    }

    agendas.forEach((a) => {
      tbody.innerHTML += `
        <tr>
          <td>${a.cod_agenda}</td>
          <td>${a.nome_cli ?? ""}</td>
          <td>${formatarDataAgenda(a.data_agenda)}</td>
          <td>${a.descricao ?? ""}</td>
          <td>${a.nome_funcionario ?? ""}</td>
          <td>
            <button class="btn btn-sm btn-primary" onclick="editarAgenda(${a.cod_agenda})">Editar</button>
            <button class="btn btn-sm btn-danger" onclick="excluirAgenda(${a.cod_agenda})">Excluir</button>
          </td>
        </tr>
      `;
    });
  } catch (err) {
    console.error("Erro carregarAgendas:", err);
    tbody.innerHTML = `<tr><td colspan="6" class="text-center text-danger">Erro ao carregar agendamentos.</td></tr>`;
  }
}

document.addEventListener("DOMContentLoaded", () => carregarAgendas());


function filtrarAgendas() {
  const input = document.getElementById("filtroData");
  if (!input || !input.value) {
    alert("Selecione uma data para filtrar!");
    return;
  }

  
  const dataFiltro = input.value.split("T")[0];
  carregarAgendas(dataFiltro);
}

function limparFiltro() {
  const el = document.getElementById("filtroData");
  if (el) el.value = "";
  carregarAgendas(); 
}


function editarAgenda(id) {
  localStorage.setItem("agenda_editar", id);
  window.location.href = "agenda_funcionario_editar.html";
}


async function excluirAgenda(id) {
  if (!confirm("Deseja realmente excluir este agendamento?")) return;

  try {
    const res = await fetch(`${BASE_URL}/agendaFuncionario/${id}`, { method: "DELETE" });
    if (res.ok) {
      alert("Agendamento excluído com sucesso!");
      carregarAgendas();
    } else {
      alert("Erro ao excluir agendamento.");
    }
  } catch (err) {
    console.error("Erro excluirAgenda:", err);
    alert("Erro de conexão ao excluir.");
  }
}


async function carregarSelectsAgenda() {
  const cliSel = document.getElementById("cod_cli");
  const funSel = document.getElementById("cod_f");
  if (!cliSel) return;

  CACHE.clientes = await fetchJsonSafe(`${BASE_URL}/clientes`, []);
  CACHE.funcionarios = await fetchJsonSafe(`${BASE_URL}/funcionarios`, []);
  CACHE.produtos = await fetchJsonSafe(`${BASE_URL}/produtos`, []);
  CACHE.servicos = await fetchJsonSafe(`${BASE_URL}/servicos`, []);
  CACHE.pacotes = await fetchJsonSafe(`${BASE_URL}/pacotes`, []);

  cliSel.innerHTML = CACHE.clientes
    .map((c) => `<option value="${c.cod_cli}">${c.cod_cli} - ${c.nome_cli}</option>`)
    .join("");

  if (funSel) {
    funSel.innerHTML =
      `<option value="">Nenhum</option>` +
      CACHE.funcionarios
        .map((f) => `<option value="${f.cod_f}">${f.cod_f} - ${f.nome_usuario}</option>`)
        .join("");
  }

  preencherListaMarcavel(CACHE.produtos, "listaProdutos", "produto");
  preencherListaMarcavel(CACHE.servicos, "listaServicos", "servico");
  preencherListaMarcavel(CACHE.pacotes, "listaPacotes", "pacote");
}
document.addEventListener("DOMContentLoaded", carregarSelectsAgenda);

function preencherListaMarcavel(itens, containerId, tipo) {
  const box = document.getElementById(containerId);
  if (!box) return;
  box.innerHTML = "";

  const codKey = `cod_${tipo}`;
  const nomeKey = `nome_${tipo}`;

  itens.forEach((i) => {
    const div = document.createElement("div");
    div.className = "d-flex align-items-center gap-2 mb-2";

    const check = document.createElement("input");
    check.type = "checkbox";
    check.id = `${tipo}_${i[codKey]}`;

    const label = document.createElement("label");
    label.setAttribute("for", check.id);
    label.textContent = `${i[codKey]} - ${i[nomeKey]}`;
    label.style.minWidth = "220px";

    const inputQtd = document.createElement("input");
    inputQtd.type = "number";
    inputQtd.min = "1";
    inputQtd.placeholder = "Qtd";
    inputQtd.className = "form-control";
    inputQtd.style.maxWidth = "90px";
    inputQtd.disabled = true;

    check.addEventListener("change", () => {
      inputQtd.disabled = !check.checked;
      if (!check.checked) inputQtd.value = "";
    });

    div.appendChild(check);
    div.appendChild(label);
    div.appendChild(inputQtd);
    box.appendChild(div);
  });
}


function addLinhaManual(containerId, tipo, lista) {
  let box = document.getElementById(containerId);
  if (!box) {
    box = document.createElement("div");
    box.id = containerId;
    box.className = "mt-2";
    const alvo =
      document.getElementById(`lista${capitalize(tipo)}s`) || document.body;
    alvo.after(box);
  }

  const codKey = `cod_${tipo}`;
  const nomeKey = `nome_${tipo}`;

  const row = document.createElement("div");
  row.className = "d-flex align-items-center gap-2 mb-2";
  row.dataset.tipo = tipo;

  const sel = document.createElement("select");
  sel.className = "form-select";
  sel.style.maxWidth = "320px";
  sel.innerHTML =
    `<option value="">Selecione ${tipo}</option>` +
    lista
      .map(
        (i) => `<option value="${i[codKey]}">${i[codKey]} - ${i[nomeKey]}</option>`
      )
      .join("");

  const qtd = document.createElement("input");
  qtd.type = "number";
  qtd.min = "1";
  qtd.placeholder = "Qtd";
  qtd.className = "form-control";
  qtd.style.maxWidth = "90px";

  const rm = document.createElement("button");
  rm.type = "button";
  rm.className = "btn btn-outline-danger";
  rm.textContent = "Remover";
  rm.onclick = () => row.remove();

  row.appendChild(sel);
  row.appendChild(qtd);
  row.appendChild(rm);
  box.appendChild(row);
}

function addProdutoAgenda() { addLinhaManual("listaProdutosExtra", "produto", CACHE.produtos); }
function addServicoAgenda() { addLinhaManual("listaServicosExtra", "servico", CACHE.servicos); }
function addPacoteAgenda()  { addLinhaManual("listaPacotesExtra",  "pacote",  CACHE.pacotes);  }

function capitalize(str) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}


async function initCadastrarAgenda() {
  const user = getAuth();
  const cod_f = await resolveCodFDoUsuario();

  
  await carregarSelectsAgenda();

  
  const funSel = document.getElementById("cod_f");
  if (funSel && user && cod_f) {
    funSel.innerHTML = `<option value="${cod_f}" selected>${cod_f} - ${user?.nome_usuario || "Funcionário"}</option>`;
    funSel.disabled = true;
  }

  const form = document.getElementById("formCadastrarAgenda");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const produtos = coletarItensSelecionados("produto");
    const servicos = coletarItensSelecionados("servico");
    const pacotes = coletarItensSelecionados("pacote");

    const payload = {
      cod_cli: document.getElementById("cod_cli").value,
      cod_f: cod_f || null, // usa o fixo do logado
      data_agenda: document.getElementById("data_agenda").value,
      descricao: document.getElementById("descricao").value,
      produtos,
      servicos,
      pacotes,
    };

    const res = await fetch(`${BASE_URL}/agendaFuncionario`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      alert("Agenda cadastrada com sucesso!");
      window.location.href = "agenda_funcionario.html";
    } else {
      console.error("Erro ao cadastrar agenda:", await res.text());
      alert("Erro ao cadastrar agenda. Verifique os dados.");
    }
  });
}
document.addEventListener("DOMContentLoaded", initCadastrarAgenda);


async function carregarAgendaEdicao() {
  const cod_f = await resolveCodFDoUsuario();
  const user = getAuth();
  if (document.getElementById("cod_f")) {
    document.getElementById("cod_f").innerHTML =
      `<option value="${cod_f}">${cod_f} - ${user?.nome_usuario || "Funcionário"}</option>`;
    document.getElementById("cod_f").disabled = true;
  }

  const cod = localStorage.getItem("agenda_editar");
  const form = document.getElementById("formEditarAgenda");
  if (!form) return;

  await carregarSelectsAgenda();

  const res = await fetch(`${BASE_URL}/agendaFuncionario/${cod}/completo`);
  const a = await res.json();

  document.getElementById("cod_agenda").value = a.cod_agenda;
  document.getElementById("cod_cli").value = a.cod_cli;
  document.getElementById("cod_f").value = a.cod_f ?? "";

  
  document.getElementById("data_agenda").value = toDatetimeLocal(a.data_agenda);

  document.getElementById("descricao").value = a.descricao ?? "";

  marcarItensSelecionados(a.produtos, "produto");
  marcarItensSelecionados(a.servicos, "servico");
  marcarItensSelecionados(a.pacotes, "pacote");
}
document.addEventListener("DOMContentLoaded", carregarAgendaEdicao);

function marcarItensSelecionados(lista, tipo) {
  if (!Array.isArray(lista)) return;
  const codKey = `cod_${tipo}`;
  const quantKey = `quant_${tipo}`;

  lista.forEach((item) => {
    const check = document.getElementById(`${tipo}_${item[codKey]}`);
    if (check) {
      check.checked = true;
      const qtdInput = check.parentElement.querySelector("input[type='number']");
      if (qtdInput) {
        qtdInput.disabled = false;
        qtdInput.value = item[quantKey];
      }
    } else {
      const addFn = {
        produto: addProdutoAgenda,
        servico: addServicoAgenda,
        pacote: addPacoteAgenda,
      }[tipo];
      addFn && addFn();
      const extras = document.querySelectorAll(
        `#lista${capitalize(tipo)}sExtra [data-tipo="${tipo}"]`
      );
      const row = extras[extras.length - 1];
      if (row) {
        const sel = row.querySelector("select");
        const qtd = row.querySelector('input[type="number"]');
        if (sel) sel.value = String(item[codKey]);
        if (qtd) qtd.value = item[quantKey];
      }
    }
  });
}


async function initEditarAgenda() {
  const form = document.getElementById("formEditarAgenda");
  if (!form) return;

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const cod = localStorage.getItem("agenda_editar");
    const produtos = coletarItensSelecionados("produto");
    const servicos = coletarItensSelecionados("servico");
    const pacotes = coletarItensSelecionados("pacote");

    const payload = {
      cod_cli: document.getElementById("cod_cli").value,
      cod_f: document.getElementById("cod_f").value || null,
      data_agenda: document.getElementById("data_agenda").value,
      descricao: document.getElementById("descricao").value,
      produtos,
      servicos,
      pacotes,
    };

    const res = await fetch(`${BASE_URL}/agendaFuncionario/${cod}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (res.ok) {
      alert("Agenda atualizada!");
      window.location.href = "agenda_funcionario.html";
    } else {
      console.error("Erro ao editar agenda:", await res.text());
    }
  });
}
document.addEventListener("DOMContentLoaded", initEditarAgenda);


function coletarItensSelecionados(tipo) {
  const resultados = [];
  const codKey = `cod_${tipo}`;
  const quantKey = `quant_${tipo}`;

  const marcados = document.querySelectorAll(
    `#lista${capitalize(tipo)}s input[type="checkbox"]:checked`
  );
  marcados.forEach((check) => {
    const id = Number(check.id.split("_")[1]);
    const qtdInput = check.parentElement.querySelector("input[type='number']");
    const qtd = Number(qtdInput?.value) || 1;
    resultados.push({ [codKey]: id, [quantKey]: qtd });
  });

  const extras = document.querySelectorAll(
    `#lista${capitalize(tipo)}sExtra [data-tipo="${tipo}"]`
  );
  extras.forEach((row) => {
    const sel = row.querySelector("select");
    const qtd = row.querySelector('input[type="number"]');
    const id = Number(sel?.value || 0);
    const q = Number(qtd?.value || 0);
    if (id > 0 && q > 0) resultados.push({ [codKey]: id, [quantKey]: q });
  });

  return resultados;
}
