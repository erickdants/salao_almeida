import pool from "../db.js";

export const loginUsuario = async (req, res) => {
  const { ID_usuario, senha_usuario } = req.body;
  if (!ID_usuario || !senha_usuario) return res.status(400).json({ erro: "ID e senha obrigatórios" });

  try {
    const q = await pool.query(
      "SELECT nome_usuario, ID_usuario, senha_usuario FROM Usuario WHERE ID_usuario = $1",
      [ID_usuario]
    );

    if (q.rowCount === 0) return res.status(401).json({ erro: "Usuário não encontrado" });

    const user = q.rows[0];

    if (user.senha_usuario !== senha_usuario) return res.status(401).json({ erro: "Senha inválida" });

    const tipo = ID_usuario.toString().startsWith("1") ? "funcionario" : ID_usuario.toString().startsWith("2") ? "adm" : "usuario";

    res.json({
      sucesso: true,
      usuario: {
        nome_usuario: user.nome_usuario,
        ID_usuario: user.ID_usuario
      },
      tipo
    });
  } catch (err) {
    console.error("loginUsuario:", err);
    res.status(500).json({ erro: err.message });
  }
};

export const listarUsuarios = async (req, res) => {
  try {
    const q = await pool.query("SELECT nome_usuario, ID_usuario FROM Usuario ORDER BY nome_usuario");
    res.json(q.rows);
  } catch (err) {
    console.error("listarUsuarios:", err);
    res.status(500).json({ erro: err.message });
  }
};

export const obterUsuarioPorId = async (req, res) => {
  const id = req.params.id;
  try {
    const q = await pool.query("SELECT nome_usuario, ID_usuario FROM Usuario WHERE ID_usuario = $1", [id]);
    if (q.rowCount === 0) return res.status(404).json({ erro: "Usuário não encontrado" });
    res.json(q.rows[0]);
  } catch (err) {
    console.error("obterUsuarioPorId:", err);
    res.status(500).json({ erro: err.message });
  }
};

export const criarUsuario = async (req, res) => {
  const { nome_usuario, ID_usuario, senha_usuario } = req.body;
  if (!nome_usuario || !ID_usuario || !senha_usuario) return res.status(400).json({ erro: "Campos obrigatórios faltando" });

  try {
    await pool.query(
      "INSERT INTO Usuario (nome_usuario, ID_usuario, senha_usuario) VALUES ($1, $2, $3)",
      [nome_usuario, ID_usuario, senha_usuario]
    );
    res.status(201).json({ sucesso: true, mensagem: "Usuário criado" });
  } catch (err) {
    console.error("criarUsuario:", err);
    // se violação de PK
    if (err.code === "23505") return res.status(409).json({ erro: "ID já existe" });
    res.status(500).json({ erro: err.message });
  }
};

export const atualizarUsuario = async (req, res) => {
  const id = req.params.id;
  const { nome_usuario, senha_usuario } = req.body;
  if (!nome_usuario && !senha_usuario) return res.status(400).json({ erro: "Nada para atualizar" });

  try {
    const parts = [];
    const values = [];
    let idx = 1;
    if (nome_usuario) { parts.push(`nome_usuario = $${idx++}`); values.push(nome_usuario); }
    if (senha_usuario) { parts.push(`senha_usuario = $${idx++}`); values.push(senha_usuario); }
    values.push(id);
    const q = `UPDATE Usuario SET ${parts.join(", ")} WHERE ID_usuario = $${idx} RETURNING nome_usuario, ID_usuario`;
    const r = await pool.query(q, values);
    if (r.rowCount === 0) return res.status(404).json({ erro: "Usuário não encontrado" });
    res.json({ sucesso: true, usuario: r.rows[0] });
  } catch (err) {
    console.error("atualizarUsuario:", err);
    res.status(500).json({ erro: err.message });
  }
};

export const excluirUsuario = async (req, res) => {
  const id = req.params.id;
  try {
    await pool.query("DELETE FROM Usuario WHERE ID_usuario = $1", [id]);
    res.json({ sucesso: true, mensagem: "Usuário removido" });
  } catch (err) {
    console.error("excluirUsuario:", err);
    res.status(500).json({ erro: err.message });
  }
};
